/**
 * Migrated from api/gateway.js.
 * Dispatcher for /api/gateway?__path=... (and pathname fallback).
 * Handlers live in this same directory (server/api).
 */
const { existsSync } = require("node:fs");
const { join, normalize } = require("node:path");
const { pathToFileURL } = require("node:url");

const ROOT = __dirname;

function segmentsFromReq(req) {
  const url = new URL(req.url || "/", "http://localhost");
  let raw = String((req.query && (req.query.__path || req.query.path)) || "").trim();
  if (!raw) {
    raw = url.searchParams.get("__path") || url.searchParams.get("path") || "";
  }
  if (!raw && url.pathname.startsWith("/api/")) {
    raw = url.pathname.replace(/^\/api\//, "").replace(/\/+$/, "");
    if (raw === "gateway") raw = "";
  }
  // When this file is hit as /api/gateway, strip self-name.
  if (raw === "gateway" || raw.startsWith("gateway/")) {
    raw = raw.replace(/^gateway\/?/, "");
  }
  return String(raw)
    .split("/")
    .map((p) => p.trim())
    .filter(Boolean)
    .filter((p) => p !== ".." && p !== "." && !p.includes("\\") && !p.startsWith("_"));
}

function resolveHandler(segments) {
  if (!segments.length) return null;
  const joined = segments.join("/");
  // Never re-enter gateway from itself.
  if (joined === "gateway" || joined.startsWith("gateway/")) return null;
  const candidates = [join(ROOT, `${joined}.js`), join(ROOT, joined, "index.js")].map((p) => normalize(p));
  for (const file of candidates) {
    if (!file.startsWith(ROOT)) continue;
    if (existsSync(file)) return file;
  }
  return null;
}

module.exports = async function handler(req, res) {
  try {
    const segments = segmentsFromReq(req);
    const file = resolveHandler(segments);
    if (!file) {
      res.statusCode = 404;
      res.setHeader("Content-Type", "application/json; charset=utf-8");
      res.end(JSON.stringify({ ok: false, message: "API not found", path: segments.join("/") }));
      return;
    }
    const mod = await import(pathToFileURL(file).href);
    const fn = mod.default || mod.handler;
    if (typeof fn !== "function") {
      res.statusCode = 500;
      res.setHeader("Content-Type", "application/json; charset=utf-8");
      res.end(JSON.stringify({ ok: false, message: "Invalid API handler" }));
      return;
    }
    await fn(req, res);
  } catch (error) {
    if (!res.headersSent) {
      res.statusCode = 500;
      res.setHeader("Content-Type", "application/json; charset=utf-8");
      res.end(JSON.stringify({ ok: false, message: error.message || "API error" }));
    }
  }
};
