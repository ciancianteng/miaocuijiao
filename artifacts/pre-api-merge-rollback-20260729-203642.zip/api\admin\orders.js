const REQUIRED_ENV = ["SUPABASE_URL", "SUPABASE_ANON_KEY", "SUPABASE_SERVICE_ROLE_KEY"];
const ADMIN_ROLES = new Set(["admin", "super_admin"]);
const ORDER_STATUS_TEXT = { awaiting_payment: "待付款确认", pending: "待接单", claimed: "陪玩已申请", waiting_boss_confirm: "待老板确认", confirmed: "已确认", in_progress: "进行中", completed: "已完成", cancelled: "已取消", refund_requested: "退款中", refunded: "已退款" };
function json(res, status, data) { return res.status(status).json(data); }
function hasDb() { return REQUIRED_ENV.every((key) => process.env[key]); }
function restUrl(table, query = "") { return `${process.env.SUPABASE_URL}/rest/v1/${table}${query}`; }
function authUrl(path) { return `${process.env.SUPABASE_URL}/auth/v1/${path}`; }
function serviceHeaders(extra = {}) { return { apikey: process.env.SUPABASE_SERVICE_ROLE_KEY, Authorization: `Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY}`, "Content-Type": "application/json", Prefer: "return=representation", ...extra }; }
function anonHeaders(extra = {}) { return { apikey: process.env.SUPABASE_ANON_KEY, "Content-Type": "application/json", ...extra }; }
function supabaseError(body, response) {
  const parts = [body?.error_description, body?.msg, body?.message, body?.error, body?.hint, body?.details, typeof body === "string" ? body : ""].filter(Boolean);
  const base = parts[0] || "Supabase 请求失败";
  const code = body?.code ? ` [${body.code}]` : "";
  return `${base}${code} (HTTP ${response.status})`;
}
async function supabaseJson(url, init = {}) { const response = await fetch(url, init); const text = await response.text(); let body = null; try { body = text ? JSON.parse(text) : null; } catch { body = text; } if (!response.ok) throw Object.assign(new Error(supabaseError(body, response)), { status: response.status }); return body; }
async function parseBody(req) { if (req.body && typeof req.body === "object") return req.body; const chunks = []; for await (const chunk of req) chunks.push(chunk); try { return JSON.parse(Buffer.concat(chunks).toString("utf8") || "{}"); } catch { return {}; } }
function tokenFrom(req) { return String(req.headers.authorization || req.headers["x-mcj-access-token"] || "").replace(/^Bearer\s+/i, "").trim(); }
async function requireAdmin(req) { const token = tokenFrom(req); if (!token) throw Object.assign(new Error("请先使用管理员账号登录后台。"), { status: 401 }); const user = await supabaseJson(authUrl("user"), { headers: anonHeaders({ Authorization: `Bearer ${token}` }) }); const rows = await supabaseJson(restUrl("profiles", `?id=eq.${encodeURIComponent(user.id)}&limit=1`), { headers: serviceHeaders() }); const profile = rows[0]; if (!profile || !ADMIN_ROLES.has(profile.role)) throw Object.assign(new Error("无权访问后台。"), { status: 403 }); if (profile.status !== "active") throw Object.assign(new Error("管理员账号已停用。"), { status: 403 }); return profile; }
function money(v) { const n = Number(String(v ?? "").replace(/[^\d.-]/g, "")); return Number.isFinite(n) ? n : 0; }
function safeOrder(row, profiles) {
  const boss = profiles[row.boss_id] || {};
  const companion = profiles[row.companion_id] || {};
  const service = profiles[row.customer_service_id] || {};
  return {
    id: row.id,
    orderNo: row.order_no || row.id,
    bossId: row.boss_id || "",
    bossUid: boss.boss_uid || "",
    bossName: boss.display_name || boss.email || boss.boss_uid || "-",
    companionName: companion.display_name || companion.email || "-",
    serviceName: service.display_name || service.email || "-",
    game: row.game || "",
    totalAmount: money(row.total_amount),
    status: row.status || "",
    statusText: ORDER_STATUS_TEXT[row.status] || row.status || "-",
    createdAt: row.created_at || "",
    description: row.description || "",
  };
}
async function addSystem(order, adminId, text) { try { const rows = await supabaseJson(restUrl("conversations", `?order_id=eq.${encodeURIComponent(order.id)}&limit=1`), { headers: serviceHeaders() }); const conv = rows[0]; if (!conv) return; await supabaseJson(restUrl("messages"), { method: "POST", headers: serviceHeaders(), body: JSON.stringify({ conversation_id: conv.id, sender_id: adminId, sender_role: "admin", message_type: "system", content: text, order_id: order.id, created_at: new Date().toISOString() }) }); } catch {} }
export default async function handler(req, res) { if (!hasDb()) return json(res, req.method === "GET" ? 200 : 503, { ok: req.method === "GET", configured: false, orders: [], message: "未配置 Supabase，后台订单不返回假数据。", orderStatuses: ORDER_STATUS_TEXT }); try { const admin = await requireAdmin(req); if (req.method === "GET") { const [orders, profiles] = await Promise.all([ supabaseJson(restUrl("orders", "?order=created_at.desc&limit=500"), { headers: serviceHeaders() }).catch(() => []), supabaseJson(restUrl("profiles", "?limit=1000"), { headers: serviceHeaders() }).catch(() => []) ]); const map = profiles.reduce((m, p) => { m[p.id] = p; return m; }, {}); return json(res, 200, { ok: true, configured: true, orders: orders.map((o) => safeOrder(o, map)), orderStatuses: ORDER_STATUS_TEXT }); }
    if (req.method !== "POST") return json(res, 405, { ok: false, message: "Method Not Allowed" }); const body = await parseBody(req); const id = String(body.id || body.order_id || ""); const action = String(body.action || ""); const rows = await supabaseJson(restUrl("orders", `?id=eq.${encodeURIComponent(id)}&limit=1`), { headers: serviceHeaders() }); const before = rows[0]; if (!before) return json(res, 404, { ok: false, message: "订单不存在。" }); let patch = {}; if (action === "update_status") patch.status = String(body.status || ""); if (action === "assign_service") patch.customer_service_id = String(body.customer_service_id || "") || null; if (action === "assign_companion") { patch.companion_id = String(body.companion_id || "") || null; patch.status = "waiting_boss_confirm"; } if (action === "cancel") { patch.status = "cancelled"; patch.cancelled_at = new Date().toISOString(); } if (action === "refund") patch.status = "refunded"; if (!Object.keys(patch).length) return json(res, 400, { ok: false, message: "未知订单操作。" }); const updated = await supabaseJson(restUrl("orders", `?id=eq.${encodeURIComponent(id)}`), { method: "PATCH", headers: serviceHeaders(), body: JSON.stringify(patch) }); await addSystem(updated[0] || before, admin.id, `后台更新订单：${ORDER_STATUS_TEXT[patch.status] || patch.status || action}`); return json(res, 200, { ok: true, message: "订单已更新。", order: updated[0] || null }); } catch (error) { return json(res, error.status || 500, { ok: false, message: error.message || "后台订单接口异常。" }); } }
