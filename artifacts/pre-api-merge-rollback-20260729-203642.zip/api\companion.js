﻿import {
  PRIVATE_BUCKETS,
  buildObjectPath,
  companionDb,
  createSignedUrl,
  decodeDataUrl,
  ensureCompanionBuckets,
  isMissingRelation,
  maskBankAccount,
  uploadPrivateObject,
} from "./_companion-media-store.js";
import { companionPopularityMe, recordOnlineSession, scheduleRecomputeSoft } from "./_popularity.js";

const WITHDRAW_STATUS_TEXT = {
  pending_review: "待审核",
  approved_pending_pay: "已通过待付款",
  rejected: "已驳回",
  paying: "付款处理中",
  paid_pending_receipt: "已付款待上传收据",
  completed: "已付款",
  pay_failed: "付款失败",
  cancelled: "已撤销",
};
const WITHDRAW_ACTIVE = new Set([
  "pending_review",
  "approved_pending_pay",
  "paying",
  "paid_pending_receipt",
  "completed",
]);

const REQUIRED_ENV = ["SUPABASE_URL", "SUPABASE_ANON_KEY", "SUPABASE_SERVICE_ROLE_KEY"];
const ORDER_STATUS_TEXT = {
  awaiting_payment: "待付款确认",
  pending: "待接单",
  claimed: "已支付待陪玩确认",
  waiting_boss_confirm: "待老板确认",
  confirmed: "待开始",
  in_progress: "进行中",
  completed: "已完成",
  cancelled: "已取消",
  refund_requested: "退款处理中",
  refunded: "已退款"
};

function json(res, status, data) { res.status(status).json(data); }
function hasDb() { return REQUIRED_ENV.every((key) => process.env[key]); }
function anonHeaders(extra = {}) { return { apikey: process.env.SUPABASE_ANON_KEY, "Content-Type": "application/json", ...extra }; }
function serviceHeaders(extra = {}) { return { apikey: process.env.SUPABASE_SERVICE_ROLE_KEY, Authorization: `Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY}`, "Content-Type": "application/json", Prefer: "return=representation", ...extra }; }
function authUrl(path) { return `${process.env.SUPABASE_URL}/auth/v1/${path}`; }
function restUrl(table, query = "") { return `${process.env.SUPABASE_URL}/rest/v1/${table}${query}`; }
function nowIso() { return new Date().toISOString(); }
function todayKey() { return new Date().toISOString().slice(0, 10); }
function monthKey() { return new Date().toISOString().slice(0, 7); }
function money(value) { const n = Number(String(value ?? "").replace(/[^\d.-]/g, "")); return Number.isFinite(n) ? n : 0; }
async function parseBody(req) { if (req.body && typeof req.body === "object") return req.body; const chunks=[]; for await (const chunk of req) chunks.push(chunk); try { return JSON.parse(Buffer.concat(chunks).toString("utf8") || "{}"); } catch { return {}; } }
async function supabaseJson(url, init = {}) { const response = await fetch(url, init); const text = await response.text(); let body=null; try { body=text?JSON.parse(text):null; } catch { body=text; } if(!response.ok) throw new Error(body?.error_description || body?.message || body?.hint || body?.details || "Supabase 请求失败"); return body; }
function tokenFrom(req) { return String(req.headers["x-mcj-companion-token"] || req.headers.authorization || "").replace(/^Bearer\s+/i, "").trim(); }
async function authUserFromToken(token) { return supabaseJson(authUrl("user"), { headers: anonHeaders({ Authorization: `Bearer ${token}` }) }); }
async function profileById(id) { const rows = await supabaseJson(restUrl("profiles", `?id=eq.${encodeURIComponent(id)}&limit=1`), { headers: serviceHeaders() }); return rows?.[0] || null; }
async function companionProfile(userId) { const rows = await supabaseJson(restUrl("companion_profiles", `?user_id=eq.${encodeURIComponent(userId)}&limit=1`), { headers: serviceHeaders() }); return rows?.[0] || null; }
async function requireCompanion(req) {
  const token = tokenFrom(req);
  if (!token) throw Object.assign(new Error("请先登录陪玩端。"), { status: 401 });
  const authUser = await authUserFromToken(token);
  const profile = await profileById(authUser.id);
  if (!profile || profile.role !== "companion") throw Object.assign(new Error("无权访问陪玩端。"), { status: 403 });
  if (profile.status === "disabled") throw Object.assign(new Error("陪玩账号已停用。"), { status: 403 });
  const companion = await companionProfile(profile.id);
  return { token, authUser, profile, companion };
}
function safePlayer(profile = {}, companion = {}) {
  return {
    id: profile.id,
    uid: profile.id,
    name: companion.nickname || profile.display_name || profile.email || "陪玩",
    avatar: profile.avatar_url || companion.card_image_url || "/assets/meow-cuijiao-brand.jpg",
    mainGame: companion.game || "",
    game: companion.game || "",
    level: companion.level_name || "未设置",
    rawPrice: money(companion.price),
    price: money(companion.price),
    bio: companion.description || "",
    onlineStatus: companion.online_status || "offline",
    workStatus: companion.online_status === "online" ? "可接单" : "暂停接单",
    accountStatus: profile.status || "pending",
    auditStatus: companion.application_status || companion.verification_status || "pending",
    depositStatus: companion.deposit_status || "pending",
    verificationStatus: companion.verification_status || "pending",
    orderCommissionRate: money(companion.commission_rate) || 80,
    giftCommissionRate: money(companion.gift_commission_rate) || 0,
    directRebateRate: money(companion.direct_rebate_rate) || 0,
    applicationRejectReason: companion.application_reject_reason || "",
    mediaRejectReason: companion.media_reject_reason || "",
    tags: companion.tags || "",
    raw: { ...profile, ...companion }
  };
}
function canWork(profile = {}, companion = {}) { return profile.status === "active" && companion.verification_status === "approved"; }
function canAccept(profile = {}, companion = {}) { return canWork(profile, companion) && companion.online_status === "online"; }
function viewOrder(row = {}, boss = {}) {
  const rate = money(row.commission_rate || row.player_commission_rate || row.companion_rate || 80) || 80;
  const amount = money(row.total_amount);
  return {
    id: row.id,
    orderNo: row.order_no || row.id,
    orderType: row.order_type || "custom",
    bossName: boss.display_name || boss.email || "老板",
    bossUid: boss.boss_uid || "",
    bossId: row.boss_id || "",
    game: row.game || "",
    serviceContent: row.description || row.title || "",
    duration: row.hours ? `${row.hours}小时` : "",
    amount,
    playerIncome: Math.round(amount * rate) / 100,
    requiredLevel: "不限",
    requiredTags: "无特殊标签",
    orderStatus: ORDER_STATUS_TEXT[row.status] || row.status || "待付款确认",
    status: row.status,
    statusText: ORDER_STATUS_TEXT[row.status] || row.status || "待付款确认",
    appointmentAt: row.created_at || "",
    createdAt: row.created_at || "",
    raw: row
  };
}
async function bossesForOrders(orders) { const ids=[...new Set((orders||[]).map((row)=>row.boss_id).filter(Boolean))]; if(!ids.length) return {}; const rows=await supabaseJson(restUrl("profiles", `?id=in.(${ids.map(encodeURIComponent).join(",")})`), { headers: serviceHeaders() }); return Object.fromEntries((rows||[]).map((row)=>[row.id,row])); }
async function loadOrdersFor(profile, companion) {
  const myRows = await supabaseJson(restUrl("orders", `?companion_id=eq.${encodeURIComponent(profile.id)}&order=created_at.desc&limit=200`), { headers: serviceHeaders() });
  const openRows = canAccept(profile, companion) ? await supabaseJson(restUrl("orders", "?status=eq.pending&order=created_at.desc&limit=100"), { headers: serviceHeaders() }) : [];
  const bossMap = await bossesForOrders([...(myRows||[]), ...(openRows||[])]);
  return {
    myOrders: (myRows || []).map((row) => viewOrder(row, bossMap[row.boss_id] || {})),
    openOrders: (openRows || []).map((row) => viewOrder(row, bossMap[row.boss_id] || {}))
  };
}
async function transactionsFor(userId) { const rows = await supabaseJson(restUrl("transactions", `?user_id=eq.${encodeURIComponent(userId)}&order=created_at.desc&limit=200`), { headers: serviceHeaders() }); return Array.isArray(rows) ? rows : []; }
async function financeSettings() {
  try {
    const rows = await companionDb("finance_settings", "?id=eq.1&limit=1");
    return (
      rows?.[0] || {
        min_withdraw_cat_food: 50,
        max_withdrawals_per_month: 3,
        cat_food_to_rm_rate: 1,
        withdraw_fee_rm: 0,
        withdraw_fee_percent: 0,
      }
    );
  } catch (e) {
    if (isMissingRelation(e)) {
      return {
        min_withdraw_cat_food: 50,
        max_withdrawals_per_month: 3,
        cat_food_to_rm_rate: 1,
        withdraw_fee_rm: 0,
        withdraw_fee_percent: 0,
      };
    }
    throw e;
  }
}
async function withdrawalsFor(userId) {
  try {
    const rows = await companionDb(
      "companion_withdrawals",
      `?companion_id=eq.${encodeURIComponent(userId)}&order=submitted_at.desc&limit=100`
    );
    return Array.isArray(rows) ? rows : [];
  } catch (e) {
    if (isMissingRelation(e)) return [];
    throw e;
  }
}
function summaryFrom(myOrders, transactions, withdrawals = []) {
  const today = todayKey();
  const month = monthKey();
  const incomeRows = (transactions || []).filter((row) => row.transaction_type === "companion_income" && row.status !== "cancelled");
  const locked = (withdrawals || [])
    .filter((w) => WITHDRAW_ACTIVE.has(w.status))
    .reduce((n, w) => n + money(w.cat_food_amount), 0);
  const gross = incomeRows.reduce((n, row) => n + money(row.amount), 0);
  return {
    todayOrders: myOrders.filter((o) => String(o.createdAt || "").slice(0,10) === today).length,
    waitingConfirm: myOrders.filter((o) => o.status === "waiting_boss_confirm").length,
    waitingStart: myOrders.filter((o) => o.status === "confirmed").length,
    runningOrders: myOrders.filter((o) => o.status === "in_progress").length,
    completedOrders: myOrders.filter((o) => o.status === "completed").length,
    monthIncome: incomeRows.filter((row) => String(row.created_at || "").slice(0,7) === month).reduce((n,row)=>n+money(row.amount),0),
    withdrawable: Math.max(0, Math.round((gross - locked) * 100) / 100),
    unreadMessages: 0,
    monthReviews: 0
  };
}
async function bootstrapData(profile, companion) {
  const player = safePlayer(profile, companion || {});
  const permissions = {
    canLogin: true,
    canWork: canWork(profile, companion || {}),
    canSetAvailable: profile.status === "active",
    canAcceptOrder: canAccept(profile, companion || {}),
    canStartOrder: canWork(profile, companion || {}),
    canWithdraw: false,
    messagesMode: "system_only",
    lockReason: canWork(profile, companion || {}) ? "" : "账号正在审核中",
  };
  const { myOrders, openOrders } = await loadOrdersFor(profile, companion || {});
  const [transactions, withdrawalRows, cfg] = await Promise.all([
    transactionsFor(profile.id),
    withdrawalsFor(profile.id),
    financeSettings(),
  ]);
  const summary = summaryFrom(myOrders, transactions, withdrawalRows);
  const earningDetails = transactions.filter((row) => row.transaction_type === "companion_income").map((row) => ({ id: row.id, orderId: row.order_id, type: "陪玩收入", amount: money(row.amount), status: row.status || "completed", createdAt: row.created_at }));

  let identity = null;
  let payment = null;
  let deposit = null;
  let media = [];
  let paymentAccounts = [];
  try {
    const [identityRows, paymentRows, depositRows, mediaRows] = await Promise.all([
      companionDb("companion_identity_verifications", `?user_id=eq.${encodeURIComponent(profile.id)}&limit=1`).catch((e) => (isMissingRelation(e) ? [] : Promise.reject(e))),
      companionDb("companion_payment_accounts", `?user_id=eq.${encodeURIComponent(profile.id)}&order=submitted_at.desc&limit=20`).catch((e) => (isMissingRelation(e) ? [] : Promise.reject(e))),
      companionDb("companion_deposits", `?user_id=eq.${encodeURIComponent(profile.id)}&order=created_at.desc&limit=1`).catch((e) => (isMissingRelation(e) ? [] : Promise.reject(e))),
      companionDb("companion_media", `?user_id=eq.${encodeURIComponent(profile.id)}&order=sort_order.asc`).catch((e) => (isMissingRelation(e) ? [] : Promise.reject(e))),
    ]);
    identity = identityRows?.[0] || null;
    paymentAccounts = Array.isArray(paymentRows) ? paymentRows : [];
    payment = paymentAccounts.find((a) => a.status === "approved" || a.status === "verified") || paymentAccounts[0] || null;
    deposit = depositRows?.[0] || null;
    media = Array.isArray(mediaRows) ? mediaRows : [];
  } catch {
    /* tables may be missing until SQL runs */
  }

  const month = monthKey();
  const usedThisMonth = withdrawalRows.filter(
    (w) => String(w.submitted_at || "").slice(0, 7) === month && !/rejected|cancelled/.test(w.status)
  ).length;
  const monthlyLimit = Number(cfg.max_withdrawals_per_month || 3);
  const minAmount = money(cfg.min_withdraw_cat_food);
  const rate = money(cfg.cat_food_to_rm_rate) || 1;
  const identityOk = /approved|verified|passed/.test(String(identity?.status || companion?.verification_status || ""));
  const bankOk = /approved|verified/.test(String(payment?.status || ""));
  const accountOk = profile.status === "active" && !companion?.withdraw_frozen;
  const canWithdrawNow =
    canWork(profile, companion || {}) &&
    identityOk &&
    bankOk &&
    accountOk &&
    summary.withdrawable >= minAmount &&
    usedThisMonth < monthlyLimit;
  permissions.canWithdraw = canWithdrawNow;
  if (!canWithdrawNow) {
    if (!identityOk) permissions.withdrawLockReason = "请先完成实名认证";
    else if (!bankOk) permissions.withdrawLockReason = "请先提交并等待结款账户审核通过";
    else if (companion?.withdraw_frozen) permissions.withdrawLockReason = "提现已被冻结";
    else if (summary.withdrawable < minAmount) permissions.withdrawLockReason = `可提现余额不足（最低 ${minAmount}）`;
    else if (usedThisMonth >= monthlyLimit) permissions.withdrawLockReason = "已达本月提现次数上限";
    else if (profile.status !== "active") permissions.withdrawLockReason = "账号状态异常";
    else permissions.withdrawLockReason = permissions.lockReason || "暂不可提现";
  }

  const feePercent = money(cfg.withdraw_fee_percent);
  const feeFixed = money(cfg.withdraw_fee_rm);
  const approvedAccounts = paymentAccounts
    .filter((a) => /approved|verified/.test(String(a.status || "")))
    .map((a) => ({
      id: a.id,
      bankName: a.bank_name || "",
      accountHolder: a.account_name || "",
      accountLast4: a.account_last4 || maskBankAccount(a.bank_account).slice(-4),
      status: a.status,
    }));

  const signedMedia = [];
  for (const item of media) {
    let url = "";
    try {
      url = await createSignedUrl(item.storage_bucket, item.storage_path, 600);
    } catch {
      url = "";
    }
    signedMedia.push({
      id: item.id,
      mediaType: item.media_type,
      status: item.status,
      rejectReason: item.reject_reason || "",
      durationSeconds: item.duration_seconds,
      uploadedAt: item.uploaded_at,
      url,
    });
  }

  let popularity = null;
  try {
    popularity = await companionPopularityMe(profile.id);
  } catch {
    popularity = null;
  }

  return {
    serverTime: nowIso(),
    player,
    permissions,
    summary,
    popularity,
    openOrders,
    myOrders,
    conversations: [],
    messages: [],
    earnings: { todayIncome: 0, weekIncome: summary.monthIncome, monthIncome: summary.monthIncome, withdrawable: summary.withdrawable },
    earningDetails,
    withdrawalRules: {
      monthlyLimit,
      usedThisMonth,
      remainingThisMonth: Math.max(0, monthlyLimit - usedThisMonth),
      minAmount,
      exchangeRate: rate,
      feeRm: feeFixed,
      feePercent,
      currentAccount: payment
        ? `${payment.bank_name || ""} ${payment.account_name || ""} ****${payment.account_last4 || maskBankAccount(payment.bank_account).slice(-4)}`
        : "",
      approvedAccounts,
    },
    withdrawals: withdrawalRows.map((w) => ({
      id: w.id,
      withdrawalNo: w.withdrawal_no,
      catFoodAmount: money(w.cat_food_amount),
      grossAmountRm: money(w.gross_amount_rm),
      feeRm: money(w.fee_rm),
      netAmountRm: money(w.net_amount_rm),
      bankName: w.bank_name || "",
      accountLast4: w.account_last4 || "",
      status: w.status,
      statusText: WITHDRAW_STATUS_TEXT[w.status] || w.status,
      rejectReason: w.reject_reason || "",
      submittedAt: w.submitted_at || w.created_at,
      paidAt: w.paid_at || "",
      bankReferenceMasked: "",
      amount: money(w.cat_food_amount),
      createdAt: w.submitted_at || w.created_at,
    })),
    verification: {
      identityStatus: identity?.status || companion?.verification_status || "pending",
      contactStatus: companion?.verification_status || "pending",
      bankStatus: payment?.status || "pending",
      depositStatus: deposit?.status || companion?.deposit_status || "pending",
      realName: identity?.real_name || "",
      bankName: payment?.bank_name || "",
      identityRejectReason: identity?.reject_reason || "",
      paymentRejectReason: payment?.reject_reason || "",
      applicationRejectReason: companion?.application_reject_reason || "",
      mediaRejectReason: companion?.media_reject_reason || "",
      depositRejectReason: deposit?.reject_reason || "",
    },
    deposit: {
      status: deposit?.status || companion?.deposit_status || "pending",
      requiredAmount: deposit?.required_amount || 100,
      paidAmount: deposit?.paid_amount || 0,
      rejectReason: deposit?.reject_reason || "",
    },
    playerGames: [],
    media: signedMedia,
    levelInfo: {
      level: companion?.level_name || "",
      levelId: companion?.level_id || "",
      orderCommissionRate: money(companion?.commission_rate) || 80,
      giftCommissionRate: money(companion?.gift_commission_rate) || 0,
      directRebateRate: money(companion?.direct_rebate_rate) || 0,
      price: money(companion?.price),
      effectiveAt: companion?.commission_effective_at || companion?.level_effective_at || "",
    },
    invitation: { records: [] },
    reviews: [],
    orderStatuses: Object.values(ORDER_STATUS_TEXT),
    paymentStatuses: [],
  };
}

async function ensureCompanionRow(profile, companion) {
  if (companion?.id) return companion;
  const rows = await supabaseJson(restUrl("companion_profiles"), {
    method: "POST",
    headers: serviceHeaders(),
    body: JSON.stringify({
      user_id: profile.id,
      nickname: profile.display_name || "",
      verification_status: "pending",
      deposit_status: "pending",
      application_status: "pending",
      online_status: "offline",
      created_at: nowIso(),
      updated_at: nowIso(),
    }),
  });
  return rows?.[0] || companion || {};
}

async function upsertByCompanion(table, companionId, userId, payload) {
  const existing = await companionDb(table, `?companion_profile_id=eq.${encodeURIComponent(companionId)}&limit=1`).catch((e) => {
    if (isMissingRelation(e)) throw Object.assign(new Error("请先执行 supabase/companion-admin-data.sql"), { status: 503 });
    throw e;
  });
  if (existing?.[0]) {
    return companionDb(table, `?id=eq.${encodeURIComponent(existing[0].id)}`, {
      method: "PATCH",
      body: JSON.stringify({ ...payload, updated_at: nowIso() }),
    });
  }
  return companionDb(table, "", {
    method: "POST",
    body: JSON.stringify({
      companion_profile_id: companionId,
      user_id: userId,
      ...payload,
      created_at: nowIso(),
      updated_at: nowIso(),
    }),
  });
}

async function saveUploadFromBody(userId, folder, bucket, dataUrlOrPath, filename) {
  if (!dataUrlOrPath) return { bucket: "", path: "" };
  if (!String(dataUrlOrPath).startsWith("data:")) {
    return { bucket, path: String(dataUrlOrPath) };
  }
  const decoded = decodeDataUrl(dataUrlOrPath);
  if (!decoded) throw Object.assign(new Error("文件格式无效"), { status: 400 });
  const objectPath = buildObjectPath(userId, folder, filename || "file");
  await uploadPrivateObject(bucket, objectPath, decoded.buffer, decoded.contentType);
  return { bucket, path: objectPath, contentType: decoded.contentType };
}
async function ensureConversation(order) { const existing=await supabaseJson(restUrl("conversations", `?order_id=eq.${encodeURIComponent(order.id)}&limit=1`), { headers: serviceHeaders() }); if(existing?.[0]) return existing[0]; const rows=await supabaseJson(restUrl("conversations"), { method:"POST", headers: serviceHeaders(), body: JSON.stringify({ boss_id: order.boss_id, companion_id: order.companion_id || null, customer_service_id: order.customer_service_id || null, order_id: order.id, status: "open", created_at: nowIso(), updated_at: nowIso() }) }); return rows?.[0] || null; }
async function addSystemMessage(order, senderId, senderRole, content) { const conversation=await ensureConversation(order); if(!conversation) return; await supabaseJson(restUrl("messages"), { method:"POST", headers: serviceHeaders(), body: JSON.stringify({ conversation_id: conversation.id, sender_id: senderId, sender_role: senderRole, message_type: "system", content, order_id: order.id, created_at: nowIso() }) }); }
async function claimOrder(profile, companion, id) {
  if (!canAccept(profile, companion)) throw Object.assign(new Error(canWork(profile, companion) ? "请先切换为上线接单。" : "账号正在审核中，不能抢单。"), { status: 403 });
  const rows = await supabaseJson(restUrl("orders", `?id=eq.${encodeURIComponent(id)}&status=eq.pending`), { method: "PATCH", headers: serviceHeaders(), body: JSON.stringify({ companion_id: profile.id, status: "waiting_boss_confirm", accepted_at: nowIso() }) });
  if (!rows?.length) throw Object.assign(new Error("该订单已被其他陪玩领取。"), { status: 409 });
  const order = rows[0];
  await addSystemMessage(order, profile.id, "companion", "陪玩已申请接单，等待老板确认。");
  return order;
}
async function patchOwnOrder(profile, id, expected, patch, message) {
  const beforeRows = await supabaseJson(restUrl("orders", `?id=eq.${encodeURIComponent(id)}&companion_id=eq.${encodeURIComponent(profile.id)}&limit=1`), { headers: serviceHeaders() });
  const before = beforeRows?.[0];
  if (!before) throw Object.assign(new Error("订单不存在。"), { status: 404 });
  if (expected && before.status !== expected) throw Object.assign(new Error("当前订单状态不能执行该操作。"), { status: 409 });
  const rows = await supabaseJson(restUrl("orders", `?id=eq.${encodeURIComponent(id)}&companion_id=eq.${encodeURIComponent(profile.id)}`), { method: "PATCH", headers: serviceHeaders(), body: JSON.stringify(patch) });
  const saved = rows?.[0] || { ...before, ...patch };
  if (message) await addSystemMessage(saved, profile.id, "companion", message);
  return saved;
}

export default async function handler(req, res) {
  if (!hasDb()) return json(res, req.method === "GET" ? 200 : 503, { ok: req.method === "GET", data: { player: {}, permissions: { canAcceptOrder: false, lockReason: "真实数据库未配置" }, summary: { todayOrders: 0, waitingConfirm: 0, runningOrders: 0, completedOrders: 0, monthIncome: 0, withdrawable: 0 }, openOrders: [], myOrders: [], earnings: {}, earningDetails: [] }, message: "未配置 Supabase，陪玩端不返回假业务数据。" });
  try {
    const action = String(req.method === "GET" ? req.query.action || "bootstrap" : (req.body?.action || ""));
    if (action === "login") {
      const body = await parseBody(req); const account=String(body.account || body.email || "").trim().toLowerCase(); const password=String(body.password || "");
      if (!account || !password) return json(res,400,{ok:false,message:"请输入邮箱和密码"});
      const auth = await supabaseJson(authUrl("token?grant_type=password"), { method:"POST", headers: anonHeaders(), body: JSON.stringify({ email: account, password }) });
      const profile = await profileById(auth.user.id);
      if (!profile || profile.role !== "companion") return json(res,403,{ok:false,message:"无权访问陪玩端"});
      if (profile.status === "disabled") return json(res,403,{ok:false,message:"陪玩账号已停用"});
      const companion = await companionProfile(profile.id);
      return json(res,200,{ok:true,session:{token:auth.access_token,user:safePlayer(profile, companion || {}),remember:!!body.remember}});
    }
    if (action === "register") {
      const body = await parseBody(req); const email=String(body.email || body.account || "").trim().toLowerCase(); const password=String(body.password || ""); const nickname=String(body.nickname || body.name || "").trim();
      if (!email || !/^\S+@\S+\.\S+$/.test(email)) return json(res,400,{ok:false,message:"请输入有效邮箱"});
      if (!password || password.length < 8) return json(res,400,{ok:false,message:"密码至少 8 位"});
      if (!nickname) return json(res,400,{ok:false,message:"请输入陪玩昵称"});
      const created = await supabaseJson(authUrl("admin/users"), { method:"POST", headers: serviceHeaders(), body: JSON.stringify({ email, password, email_confirm: true, user_metadata: { display_name: nickname } }) });
      await supabaseJson(restUrl("profiles"), { method:"POST", headers: serviceHeaders(), body: JSON.stringify({ id: created.id, role: "companion", display_name: nickname, email, phone: String(body.phone || ""), status: "active", created_at: nowIso() }) });
      await supabaseJson(restUrl("companion_profiles"), { method:"POST", headers: serviceHeaders(), body: JSON.stringify({ user_id: created.id, nickname, verification_status: "pending", deposit_status: "pending", online_status: "offline", created_at: nowIso(), updated_at: nowIso() }) });
      const auth = await supabaseJson(authUrl("token?grant_type=password"), { method:"POST", headers: anonHeaders(), body: JSON.stringify({ email, password }) });
      const profile = await profileById(created.id);
      const companion = await companionProfile(created.id);
      return json(res,200,{ok:true,message:"陪玩账号已创建，请继续提交资料审核。",session:{token:auth.access_token,user:safePlayer(profile, companion || {}),remember:!!body.remember}});
    }
    const auth = await requireCompanion(req);
    const companion = auth.companion || await companionProfile(auth.profile.id) || {};
    if (req.method === "GET" && action === "bootstrap") return json(res,200,{ok:true,data:await bootstrapData(auth.profile, companion)});
    if (req.method !== "POST") return json(res,405,{ok:false,message:"Method Not Allowed"});
    const body = await parseBody(req);
    if (action === "accept_order") { const order=await claimOrder(auth.profile, companion, String(body.id || "")); return json(res,200,{ok:true,message:"申请接单成功，等待老板确认。",order}); }
    if (action === "accept_direct_order") {
      const id = String(body.id || "");
      const order = await patchOwnOrder(auth.profile, id, "claimed", { status: "confirmed", accepted_at: nowIso() }, "陪玩已接受直选订单。");
      return json(res, 200, { ok: true, message: "已接受订单", order });
    }
    if (action === "reject_direct_order") {
      const id = String(body.id || "");
      const beforeRows = await supabaseJson(restUrl("orders", `?id=eq.${encodeURIComponent(id)}&companion_id=eq.${encodeURIComponent(auth.profile.id)}&limit=1`), { headers: serviceHeaders() });
      const before = beforeRows?.[0];
      if (!before || before.status !== "claimed") return json(res, 409, { ok: false, message: "当前订单不能拒绝" });
      const refundAmount = money(before.paid_cat_food || before.total_amount);
      const order = await patchOwnOrder(auth.profile, id, "claimed", { status: "cancelled", cancelled_at: nowIso() }, "陪玩已拒绝直选订单，猫粮将退回老板。");
      if (refundAmount > 0) {
        try {
          const { creditWallet } = await import("./_wallet.js");
          await creditWallet({
            bossId: before.boss_id,
            amount: refundAmount,
            transactionType: "refund",
            balanceType: "paid",
            idempotencyKey: `reject-refund:${before.id}`,
            reason: `陪玩拒绝订单退款 ${before.order_no}`,
            relatedOrderId: before.id,
            operatorId: auth.profile.id,
          });
        } catch (e) {
          /* refund best-effort; admin can reconcile */
        }
      }
      try {
        await supabaseJson(restUrl("orders", `?id=eq.${encodeURIComponent(id)}`), {
          method: "PATCH",
          headers: serviceHeaders(),
          body: JSON.stringify({ cancel_reason: "陪玩拒单", note: "陪玩拒单" }),
        });
      } catch {
        /* optional columns */
      }
      scheduleRecomputeSoft();
      return json(res, 200, { ok: true, message: "已拒绝，猫粮已原路退回", order });
    }
    if (action === "start_order") { const order=await patchOwnOrder(auth.profile, String(body.id || ""), "confirmed", { status:"in_progress", started_at: nowIso() }, "陪玩已开始订单。"); return json(res,200,{ok:true,message:"订单已开始。",order}); }
    if (action === "complete_order" || action === "confirm_complete") { const order=await patchOwnOrder(auth.profile, String(body.id || ""), "in_progress", { status:"completed", completed_at: nowIso() }, "陪玩已完成订单。"); const rate=money(companion.commission_rate) || 80; const income=Math.round(money(order.total_amount)*rate)/100; await supabaseJson(restUrl("transactions"), { method:"POST", headers: serviceHeaders(), body: JSON.stringify({ user_id: auth.profile.id, order_id: order.id, transaction_type:"companion_income", amount: income, status:"completed", note:`订单完成收入，分成比例 ${rate}%`, created_at: nowIso() }) }); scheduleRecomputeSoft(); return json(res,200,{ok:true,message:"订单已完成，收入已生成。",order}); }
    if (action === "set_online_status") {
      const allowed = new Set(["online", "busy", "paused", "offline"]);
      const raw = String(body.online_status || body.availability_status || body.status || "offline").toLowerCase();
      const status = allowed.has(raw) ? raw : body.online_status === "online" ? "online" : "paused";
      if (auth.profile.status !== "active") return json(res, 403, { ok: false, message: "账号已停用，不能接单" });
      const patch = {
        online_status: status === "online" ? "online" : status === "busy" ? "busy" : status === "paused" ? "paused" : "offline",
        availability_status: status,
        status_updated_at: nowIso(),
        updated_at: nowIso(),
      };
      if (status === "online") patch.last_online_at = nowIso();
      try {
        const rows = await supabaseJson(restUrl("companion_profiles", `?user_id=eq.${encodeURIComponent(auth.profile.id)}`), {
          method: "PATCH",
          headers: serviceHeaders(),
          body: JSON.stringify(patch),
        });
        await recordOnlineSession(auth.profile.id, status);
        return json(res, 200, {
          ok: true,
          message: ({ online: "已上线可接单", busy: "已设为忙碌", paused: "已暂停接单", offline: "已离线" })[status],
          profile: rows?.[0] || null,
        });
      } catch (e) {
        const rows = await supabaseJson(restUrl("companion_profiles", `?user_id=eq.${encodeURIComponent(auth.profile.id)}`), {
          method: "PATCH",
          headers: serviceHeaders(),
          body: JSON.stringify({ online_status: status === "online" ? "online" : "paused", updated_at: nowIso() }),
        });
        await recordOnlineSession(auth.profile.id, status === "online" ? "online" : "offline");
        return json(res, 200, {
          ok: true,
          message: status === "online" ? "已上线接单" : "已暂停接单",
          profile: rows?.[0] || null,
        });
      }
    }
    if (action === "update_profile") {
      const patch = {
        nickname: String(body.nickname || ""),
        game: String(body.main_game || body.game || ""),
        main_service: String(body.main_service || body.mainService || companion.main_service || ""),
        description: String(body.bio || body.description || ""),
        card_image_url: String(body.card_image_url || body.avatar_url || companion.card_image_url || ""),
        voice_url: String(body.voice_url || companion.voice_url || ""),
        price: money(body.price),
        age: body.age ? Number(body.age) : companion.age || null,
        gender: String(body.gender || companion.gender || ""),
        region: String(body.region || companion.region || ""),
        tags: String(body.tags || companion.tags || ""),
        contact_phone: String(body.contact_phone || body.phone || companion.contact_phone || ""),
        game_rank: String(body.rank || body.game_rank || companion.game_rank || ""),
        position: String(body.position || companion.position || ""),
        schedule: String(body.schedule || companion.schedule || ""),
        online_status: body.online_status === "online" ? "online" : (companion.online_status || "offline"),
        updated_at: nowIso(),
      };
      Object.keys(patch).forEach((k) => patch[k] === undefined && delete patch[k]);
      try {
        if (!companion.id) {
          await supabaseJson(restUrl("companion_profiles"), {
            method: "POST",
            headers: serviceHeaders(),
            body: JSON.stringify({ user_id: auth.profile.id, ...patch, verification_status: "pending", deposit_status: "pending", created_at: nowIso() }),
          });
        } else {
          await supabaseJson(restUrl("companion_profiles", `?user_id=eq.${encodeURIComponent(auth.profile.id)}`), {
            method: "PATCH",
            headers: serviceHeaders(),
            body: JSON.stringify(patch),
          });
        }
      } catch (error) {
        // fallback without extended columns
        const core = {
          nickname: patch.nickname,
          game: patch.game,
          description: patch.description,
          card_image_url: patch.card_image_url,
          voice_url: patch.voice_url,
          price: patch.price,
          online_status: patch.online_status,
          updated_at: patch.updated_at,
        };
        await supabaseJson(restUrl("companion_profiles", `?user_id=eq.${encodeURIComponent(auth.profile.id)}`), {
          method: "PATCH",
          headers: serviceHeaders(),
          body: JSON.stringify(core),
        });
      }
      if (body.avatar_url || body.contact_phone || body.phone || patch.nickname) {
        await supabaseJson(restUrl("profiles", `?id=eq.${encodeURIComponent(auth.profile.id)}`), {
          method: "PATCH",
          headers: serviceHeaders(),
          body: JSON.stringify({
            avatar_url: String(body.avatar_url || auth.profile.avatar_url || ""),
            display_name: patch.nickname || auth.profile.display_name,
            phone: String(body.contact_phone || body.phone || auth.profile.phone || ""),
          }),
        });
      }
      return json(res, 200, { ok: true, message: "资料已保存，等待后台审核。" });
    }

    if (action === "submit_verification") {
      const row = await ensureCompanionRow(auth.profile, companion);
      await ensureCompanionBuckets();
      const front = await saveUploadFromBody(auth.profile.id, "id-front", PRIVATE_BUCKETS.identity, body.id_front || body.idFront, "id-front.jpg");
      const back = await saveUploadFromBody(auth.profile.id, "id-back", PRIVATE_BUCKETS.identity, body.id_back || body.idBack, "id-back.jpg");
      const handheld = await saveUploadFromBody(
        auth.profile.id,
        "id-handheld",
        PRIVATE_BUCKETS.identity,
        body.id_handheld || body.idHandheld,
        "id-handheld.jpg"
      );
      await upsertByCompanion("companion_identity_verifications", row.id, auth.profile.id, {
        real_name: String(body.real_name || body.realName || ""),
        identity_no: String(body.identity_no || body.identityNo || ""),
        id_front_path: front.path || "",
        id_back_path: back.path || "",
        id_handheld_path: handheld.path || "",
        status: "pending",
        reject_reason: "",
        submitted_at: nowIso(),
      });
      if (body.bank_name || body.bank_account || body.settlementMethod || body.method || body.tng_account || body.alipay_account) {
        await upsertByCompanion("companion_payment_accounts", row.id, auth.profile.id, {
          method: String(body.settlementMethod || body.method || body.payment_method || "bank"),
          bank_name: String(body.bank_name || body.bankName || ""),
          account_name: String(body.account_name || body.accountName || body.real_name || ""),
          bank_account: String(body.bank_account || body.bankAccount || ""),
          account_last4: String(body.bank_account || body.bankAccount || "")
            .replace(/\s+/g, "")
            .slice(-4),
          tng_account: String(body.tng_account || body.tngAccount || ""),
          alipay_account: String(body.alipay_account || body.alipayAccount || ""),
          status: "pending",
          reject_reason: "",
          submitted_at: nowIso(),
        });
      }
      await supabaseJson(restUrl("companion_profiles", `?id=eq.${encodeURIComponent(row.id)}`), {
        method: "PATCH",
        headers: serviceHeaders(),
        body: JSON.stringify({ verification_status: "pending", updated_at: nowIso() }),
      });
      return json(res, 200, { ok: true, message: "认证资料已提交，等待后台审核。" });
    }

    if (action === "submit_deposit_proof") {
      const row = await ensureCompanionRow(auth.profile, companion);
      await ensureCompanionBuckets();
      const proof = await saveUploadFromBody(
        auth.profile.id,
        "deposit",
        PRIVATE_BUCKETS.payment,
        body.proof_url || body.proofUrl || body.proof,
        "deposit-proof.jpg"
      );
      await upsertByCompanion("companion_deposits", row.id, auth.profile.id, {
        required_amount: money(body.required_amount || 100) || 100,
        paid_amount: money(body.paid_amount || body.paidAmount),
        payment_method: String(body.payment_method || body.paymentMethod || ""),
        proof_path: proof.path || "",
        proof_bucket: proof.bucket || PRIVATE_BUCKETS.payment,
        status: "pending",
        reject_reason: "",
        remark: String(body.remark || ""),
        paid_at: nowIso(),
      });
      await supabaseJson(restUrl("companion_profiles", `?id=eq.${encodeURIComponent(row.id)}`), {
        method: "PATCH",
        headers: serviceHeaders(),
        body: JSON.stringify({ deposit_status: "pending", updated_at: nowIso() }),
      });
      return json(res, 200, { ok: true, message: "押金凭证已提交，等待后台确认。" });
    }

    if (action === "upload_media") {
      const row = await ensureCompanionRow(auth.profile, companion);
      await ensureCompanionBuckets();
      const mediaType = String(body.media_type || body.mediaType || "gallery");
      const bucket =
        mediaType === "voice" ? PRIVATE_BUCKETS.audio : mediaType === "avatar" ? PRIVATE_BUCKETS.gallery : PRIVATE_BUCKETS.gallery;
      const uploaded = await saveUploadFromBody(
        auth.profile.id,
        mediaType,
        bucket,
        body.data_url || body.dataUrl || body.file,
        body.filename || mediaType
      );
      if (!uploaded.path) return json(res, 400, { ok: false, message: "缺少上传文件" });
      await companionDb("companion_media", "", {
        method: "POST",
        body: JSON.stringify({
          companion_profile_id: row.id,
          user_id: auth.profile.id,
          media_type: mediaType,
          storage_bucket: uploaded.bucket,
          storage_path: uploaded.path,
          content_type: uploaded.contentType || "",
          duration_seconds: body.duration_seconds != null ? Number(body.duration_seconds) : null,
          status: "pending",
          sort_order: Number(body.sort_order || 100),
          uploaded_at: nowIso(),
          created_at: nowIso(),
          updated_at: nowIso(),
        }),
      });
      const companionPatch = { media_status: "pending", media_reject_reason: "", updated_at: nowIso() };
      if (mediaType === "avatar") {
        companionPatch.card_image_url = "";
        await supabaseJson(restUrl("profiles", `?id=eq.${encodeURIComponent(auth.profile.id)}`), {
          method: "PATCH",
          headers: serviceHeaders(),
          body: JSON.stringify({ avatar_url: "" }),
        });
      }
      if (mediaType === "voice") companionPatch.voice_url = "";
      await supabaseJson(restUrl("companion_profiles", `?id=eq.${encodeURIComponent(row.id)}`), {
        method: "PATCH",
        headers: serviceHeaders(),
        body: JSON.stringify(companionPatch),
      });
      return json(res, 200, { ok: true, message: "媒体已上传，等待后台审核。" });
    }

    if (action === "submit_application") {
      const row = await ensureCompanionRow(auth.profile, companion);
      const patch = {
        main_service: String(body.main_service || body.mainService || ""),
        game: String(body.main_game || body.game || body.mainGame || ""),
        game_rank: String(body.rank || body.game_rank || ""),
        position: String(body.position || ""),
        voice_type: String(body.voice_type || body.voiceType || ""),
        schedule: String(body.schedule || ""),
        application_note: String(body.note || body.application_note || ""),
        tags: String(body.tags || ""),
        application_status: "pending",
        application_reject_reason: "",
        application_submitted_at: nowIso(),
        verification_status: "pending",
        updated_at: nowIso(),
      };
      try {
        await supabaseJson(restUrl("companion_profiles", `?id=eq.${encodeURIComponent(row.id)}`), {
          method: "PATCH",
          headers: serviceHeaders(),
          body: JSON.stringify(patch),
        });
      } catch {
        await supabaseJson(restUrl("companion_profiles", `?id=eq.${encodeURIComponent(row.id)}`), {
          method: "PATCH",
          headers: serviceHeaders(),
          body: JSON.stringify({
            game: patch.game,
            verification_status: "pending",
            updated_at: nowIso(),
          }),
        });
      }
      return json(res, 200, { ok: true, message: "陪玩申请已提交，等待后台审核。" });
    }

    if (action === "request_withdrawal") {
      const amount = money(body.amount || body.cat_food_amount || body.catFoodAmount);
      const remark = String(body.remark || body.note || "").trim();
      const accountId = String(body.paymentAccountId || body.payment_account_id || "").trim();
      const data = await bootstrapData(auth.profile, companion);
      if (!data.permissions.canWithdraw) {
        return json(res, 400, { ok: false, message: data.permissions.withdrawLockReason || "暂不可提现" });
      }
      if (amount <= 0) return json(res, 400, { ok: false, message: "请输入提现猫粮数量" });
      if (amount < money(data.withdrawalRules.minAmount)) {
        return json(res, 400, { ok: false, message: `最低提现 ${data.withdrawalRules.minAmount} 猫粮` });
      }
      if (amount > money(data.earnings.withdrawable)) {
        return json(res, 400, { ok: false, message: "可提现余额不足" });
      }
      const accounts = data.withdrawalRules.approvedAccounts || [];
      const account = accounts.find((a) => a.id === accountId) || accounts[0];
      if (!account) return json(res, 400, { ok: false, message: "没有已审核通过的结款账户，请先提交并等待审核" });

      const fullAccounts = await companionDb(
        "companion_payment_accounts",
        `?id=eq.${encodeURIComponent(account.id)}&limit=1`
      ).catch(() => []);
      const full = fullAccounts?.[0];
      if (!full || !/approved|verified/.test(String(full.status || ""))) {
        return json(res, 400, { ok: false, message: "结款账户未审核通过" });
      }

      const rate = money(data.withdrawalRules.exchangeRate) || 1;
      const gross = Math.round(amount * rate * 100) / 100;
      const fee = Math.round((money(data.withdrawalRules.feeRm) + gross * (money(data.withdrawalRules.feePercent) / 100)) * 100) / 100;
      const net = Math.max(0, Math.round((gross - fee) * 100) / 100);
      const last4 = full.account_last4 || maskBankAccount(full.bank_account).slice(-4);

      const rows = await companionDb("companion_withdrawals", "", {
        method: "POST",
        body: JSON.stringify({
          withdrawal_no: `WD-${Date.now()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`,
          companion_id: auth.profile.id,
          payment_account_id: full.id,
          cat_food_amount: amount,
          exchange_rate: rate,
          gross_amount_rm: gross,
          fee_rm: fee,
          net_amount_rm: net,
          bank_name: full.bank_name || "",
          account_holder: full.account_name || "",
          account_last4: last4,
          remark,
          status: "pending_review",
          submitted_at: nowIso(),
          created_at: nowIso(),
          updated_at: nowIso(),
        }),
      });
      return json(res, 200, {
        ok: true,
        message: "提现申请已提交，等待后台审核",
        preview: {
          catFoodAmount: amount,
          grossAmountRm: gross,
          feeRm: fee,
          netAmountRm: net,
          bankName: full.bank_name,
          accountHolder: full.account_name,
          accountLast4: last4,
        },
        item: rows?.[0] || null,
      });
    }

    return json(res,400,{ok:false,message:"未知陪玩端操作"});
  } catch (error) {
    return json(res,error.status || 500,{ok:false,message:error.message || "陪玩端接口异常"});
  }
}

