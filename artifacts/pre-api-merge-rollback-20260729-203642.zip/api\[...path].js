/**
 * Single Vercel serverless entry (Hobby ≤12 functions).
 * Routes /api/* → ../server/api/*.js (same handlers Vite uses locally).
 * CommonJS for Vercel Node runtime (matches former api/gateway.js).
 */
const { existsSync } = require("node:fs");
const { join, normalize } = require("node:path");
const { pathToFileURL } = require("node:url");

const ROOT = join(__dirname, "..", "server", "api");

function cleanSegments(raw) {
  const parts = Array.isArray(raw) ? raw : String(raw || "").split("/");
  return parts
    .map((p) => String(p || "").trim())
    .filter(Boolean)
    .filter((p) => p !== ".." && p !== "." && !p.includes("\\") && !p.startsWith("_"));
}

function segmentsFromReq(req) {
  const url = new URL(req.url || "/", "http://localhost");

  // Prefer explicit rewrite param (legacy gateway style).
  const viaQuery =
    (req.query && (req.query.__path || req.query.path)) ||
    url.searchParams.get("__path") ||
    url.searchParams.get("path") ||
    "";
  // Vercel catch-all sets req.query.path to the remainder after /api/.
  // If the only segment is "gateway", treat like the old /api/gateway entry.
  let raw = String(viaQuery || "").trim();
  if (Array.isArray(req.query?.path) && !url.searchParams.get("__path")) {
    const joined = req.query.path.join("/");
    if (joined && joined !== "gateway") raw = joined;
    else if (!raw) raw = joined;
  } else if (!raw && typeof req.query?.path === "string") {
    raw = req.query.path;
  }

  if (!raw && url.pathname.startsWith("/api/")) {
    raw = url.pathname.replace(/^\/api\//, "").replace(/\/+$/, "");
  }

  if (raw === "gateway" || String(raw).startsWith("gateway/")) {
    // /api/gateway or /api/gateway/orders → strip self, then look at __path if empty
    const stripped = String(raw).replace(/^gateway\/?/, "");
    raw = stripped || url.searchParams.get("__path") || "";
  }

  return cleanSegments(raw);
}

function resolveHandler(segments) {
  if (!segments.length) return null;
  const joined = segments.join("/");
  const candidates = [join(ROOT, `${joined}.js`), join(ROOT, joined, "index.js")].map((p) => normalize(p));
  for (const file of candidates) {
    if (!file.startsWith(ROOT)) continue;
    if (existsSync(file)) return file;
  }
  return null;
}

module.exports = async function handler(req, res) {
  try {
    const segments = segmentsFromReq(req);
    const file = resolveHandler(segments);
    if (!file) {
      res.statusCode = 404;
      res.setHeader("Content-Type", "application/json; charset=utf-8");
      res.end(JSON.stringify({ ok: false, message: "API not found", path: segments.join("/") }));
      return;
    }
    const mod = await import(pathToFileURL(file).href);
    const fn = mod.default || mod.handler;
    if (typeof fn !== "function") {
      res.statusCode = 500;
      res.setHeader("Content-Type", "application/json; charset=utf-8");
      res.end(JSON.stringify({ ok: false, message: "Invalid API handler" }));
      return;
    }
    await fn(req, res);
  } catch (error) {
    if (!res.headersSent) {
      res.statusCode = 500;
      res.setHeader("Content-Type", "application/json; charset=utf-8");
      res.end(JSON.stringify({ ok: false, message: error.message || "API error" }));
    }
  }
};
