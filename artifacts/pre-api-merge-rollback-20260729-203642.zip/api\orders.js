﻿import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

loadLocalEnv();

function loadLocalEnv() {
  const apiDir = path.dirname(fileURLToPath(import.meta.url));
  const envPath = path.resolve(apiDir, "..", ".env.local");
  if (!fs.existsSync(envPath)) return;
  for (const rawLine of fs.readFileSync(envPath, "utf8").split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith("#")) continue;
    const eq = line.indexOf("=");
    if (eq === -1) continue;
    const key = line.slice(0, eq).trim();
    const value = line.slice(eq + 1).trim().replace(/^["']|["']$/g, "");
    if (key && value && !process.env[key]) process.env[key] = value;
  }
}
function envValue(key) {
  if (key === "SUPABASE_URL") return process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL || "";
  if (key === "SUPABASE_ANON_KEY") return process.env.SUPABASE_ANON_KEY || process.env.VITE_SUPABASE_ANON_KEY || "";
  return process.env[key] || "";
}const REQUIRED_ENV = ["SUPABASE_URL", "SUPABASE_ANON_KEY", "SUPABASE_SERVICE_ROLE_KEY"];
const TABLE = "orders";
const STATUS_TEXT = {
  awaiting_payment: "待付款",
  pending: "待客服安排",
  claimed: "待客服安排",
  waiting_boss_confirm: "待我确认",
  confirmed: "进行中",
  in_progress: "进行中",
  completed: "已完成",
  cancelled: "已取消",
  refund_requested: "售后",
  refunded: "售后"
};

function json(res, status, data) { res.status(status).json(data); }
function hasDb() { return REQUIRED_ENV.every((key) => envValue(key)); }
function anonHeaders(extra = {}) { return { apikey: envValue("SUPABASE_ANON_KEY"), "Content-Type": "application/json", ...extra }; }
function serviceHeaders(extra = {}) { const key = envValue("SUPABASE_SERVICE_ROLE_KEY"); const base = { apikey: key, "Content-Type": "application/json", Prefer: "return=representation", "User-Agent": "MCJ-Server/1.0", ...extra }; if (!key.startsWith("sb_secret_")) base.Authorization = `Bearer ${key}`; return base; }
function restUrl(table, query = "") { return `${envValue("SUPABASE_URL")}/rest/v1/${table}${query}`; }
function authUrl(path) { return `${envValue("SUPABASE_URL")}/auth/v1/${path}`; }
function money(value) { const n = Number(String(value ?? "").replace(/[^\d.-]/g, "")); return Number.isFinite(n) ? n : 0; }
function nowIso() { return new Date().toISOString(); }
function orderNo() { return `MCJ-${Date.now()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`; }
function paymentMethodLabel(method) {
  const key = String(method || "").toLowerCase();
  if (/tng/.test(key)) return "TNG";
  if (/bank|银行/.test(key)) return "银行卡";
  if (/alipay|支付宝/.test(key)) return "支付宝";
  if (/cat.?food|wallet|猫粮|余额/.test(key)) return "猫粮余额";
  return method || "猫粮余额";
}

async function parseBody(req) {
  if (req.body && typeof req.body === "object") return req.body;
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  try { return JSON.parse(Buffer.concat(chunks).toString("utf8") || "{}"); } catch { return {}; }
}
async function supabaseJson(url, init = {}) {
  const response = await fetch(url, init);
  const text = await response.text();
  let body = null;
  try { body = text ? JSON.parse(text) : null; } catch { body = text; }
  if (!response.ok) {
    const detail =
      body?.error_description ||
      body?.message ||
      body?.hint ||
      body?.details ||
      (typeof body === "string" ? body : "") ||
      "";
    const code = body?.code ? ` [${body.code}]` : "";
    const err = new Error((detail ? `${detail}${code}` : `Supabase 请求失败${code} (HTTP ${response.status})`) || "Supabase 请求失败");
    err.status = response.status;
    err.code = body?.code || "";
    err.body = body;
    throw err;
  }
  return body;
}
function isMissingWalletRpc(error) {
  const text = `${error?.message || ""} ${error?.code || ""} ${JSON.stringify(error?.body || {})}`;
  return (
    error?.status === 404 ||
    /Could not find the function|schema cache|PGRST202|function .* does not exist|mcj_wallet_debit/i.test(text)
  );
}
function isWalletBalanceError(error) {
  const text = String(error?.message || "");
  return /余额不足|insufficient balance|wallet is frozen|账户冻结|钱包冻结/i.test(text);
}
function tokenFrom(req) {
  return String(req.headers.authorization || req.headers["x-mcj-access-token"] || "").replace(/^Bearer\s+/i, "").trim();
}
async function profileFromToken(req) {
  const token = tokenFrom(req);
  if (!token) throw Object.assign(new Error("请先登录老板账号。"), { status: 401 });
  const authUser = await supabaseJson(authUrl("user"), { headers: anonHeaders({ Authorization: `Bearer ${token}` }) });
  const rows = await supabaseJson(restUrl("profiles", `?id=eq.${encodeURIComponent(authUser.id)}&limit=1`), { headers: serviceHeaders() });
  const profile = Array.isArray(rows) ? rows[0] : null;
  if (!profile) throw Object.assign(new Error("账号未绑定平台资料。"), { status: 403 });
  if (profile.role !== "boss") throw Object.assign(new Error("只有老板账号可以执行该操作。"), { status: 403 });
  if (profile.status !== "active") throw Object.assign(new Error("老板账号未启用。"), { status: 403 });
  return profile;
}
function viewOrder(row = {}) {
  return {
    id: row.id,
    orderNo: row.order_no || row.id,
    order_no: row.order_no || row.id,
    bossId: row.boss_id || "",
    companionId: row.companion_id || "",
    customerServiceId: row.customer_service_id || "",
    orderType: row.order_type || "custom",
    game: row.game || "",
    title: row.title || "",
    description: row.description || "",
    hours: Number(row.hours || 0),
    unitPrice: money(row.unit_price),
    totalAmount: money(row.total_amount),
    amount: money(row.total_amount),
    status: row.status || "awaiting_payment",
    statusText: STATUS_TEXT[row.status] || row.status || "待付款确认",
    createdAt: row.created_at || "",
    acceptedAt: row.accepted_at || "",
    startedAt: row.started_at || "",
    completedAt: row.completed_at || "",
    cancelledAt: row.cancelled_at || "",
    companion: row.companion || null,
    customerService: row.customerService || null
  };
}
async function loadOrders(profile, id = "") {
  const query = id
    ? `?id=eq.${encodeURIComponent(id)}&boss_id=eq.${encodeURIComponent(profile.id)}&order=created_at.desc&limit=1`
    : `?boss_id=eq.${encodeURIComponent(profile.id)}&order=created_at.desc&limit=200`;
  const rows = await supabaseJson(restUrl(TABLE, query), { headers: serviceHeaders() });
  const orders = Array.isArray(rows) ? rows : [];
  const companionIds = [...new Set(orders.map((row) => row.companion_id).filter(Boolean))];
  const serviceIds = [...new Set(orders.map((row) => row.customer_service_id).filter(Boolean))];
  let companions = [];
  let services = [];
  if (companionIds.length) companions = await supabaseJson(restUrl("profiles", `?id=in.(${companionIds.map(encodeURIComponent).join(",")})`), { headers: serviceHeaders() });
  if (serviceIds.length) services = await supabaseJson(restUrl("profiles", `?id=in.(${serviceIds.map(encodeURIComponent).join(",")})`), { headers: serviceHeaders() });
  const companionMap = Object.fromEntries((companions || []).map((p) => [p.id, p]));
  const serviceMap = Object.fromEntries((services || []).map((p) => [p.id, p]));
  return orders.map((row) => viewOrder({ ...row, companion: companionMap[row.companion_id] || null, customerService: serviceMap[row.customer_service_id] || null }));
}
async function ensureConversation(order, bossId) {
  const existing = await supabaseJson(restUrl("conversations", `?order_id=eq.${encodeURIComponent(order.id)}&limit=1`), { headers: serviceHeaders() });
  if (existing?.[0]) return existing[0];
  const rows = await supabaseJson(restUrl("conversations"), {
    method: "POST",
    headers: serviceHeaders(),
    body: JSON.stringify({ boss_id: bossId, companion_id: order.companion_id || null, customer_service_id: order.customer_service_id || null, order_id: order.id, status: "open", created_at: nowIso(), updated_at: nowIso() })
  });
  return rows?.[0] || null;
}
async function addSystemMessage(order, bossId, content) {
  const conversation = await ensureConversation(order, bossId);
  if (!conversation) return;
  await supabaseJson(restUrl("messages"), {
    method: "POST",
    headers: serviceHeaders(),
    body: JSON.stringify({ conversation_id: conversation.id, sender_id: bossId, sender_role: "boss", message_type: "system", content, order_id: order.id, created_at: nowIso() })
  });
}
async function patchOwnedOrder(profile, id, allowedStatuses, patch, message) {
  const beforeRows = await supabaseJson(restUrl(TABLE, `?id=eq.${encodeURIComponent(id)}&boss_id=eq.${encodeURIComponent(profile.id)}&limit=1`), { headers: serviceHeaders() });
  const before = beforeRows?.[0];
  if (!before) throw Object.assign(new Error("订单不存在。"), { status: 404 });
  if (allowedStatuses && !allowedStatuses.includes(before.status)) throw Object.assign(new Error("当前订单状态不能执行该操作。"), { status: 409 });
  const rows = await supabaseJson(restUrl(TABLE, `?id=eq.${encodeURIComponent(id)}&boss_id=eq.${encodeURIComponent(profile.id)}`), { method: "PATCH", headers: serviceHeaders(), body: JSON.stringify(patch) });
  const saved = rows?.[0] || { ...before, ...patch };
  if (message) await addSystemMessage(saved, profile.id, message);
  return viewOrder(saved);
}

export default async function handler(req, res) {
  if (!hasDb()) {
    return json(res, 503, { ok: false, configured: false, message: "未配置 Supabase，老板订单不能读取或保存真实数据库。" });
  }
  try {
    const profile = await profileFromToken(req);
    if (req.method === "GET") {
      const orders = await loadOrders(profile, String(req.query.id || ""));
      return json(res, 200, { ok: true, configured: true, orders, statusText: STATUS_TEXT });
    }
    if (req.method !== "POST") {
      res.setHeader("Allow", "GET, POST");
      return json(res, 405, { ok: false, message: "Method Not Allowed" });
    }
    const body = await parseBody(req);
    const action = String(body.action || "create");
    if (action === "create" || action === "place_order") {
      const order = body.order || body;
      let companionId = String(order.companion_id || order.companionId || body.companionId || "").trim();
      if (action === "place_order" && !companionId) {
        return json(res, 400, { ok: false, message: "缺少陪玩信息，无法下单。" });
      }
      const hours = Math.max(0.5, money(order.hours || order.duration || order.quantity || 1));
      const unitPrice = money(order.unit_price || order.unitPrice || order.price || order.budget || 0);
      let totalAmount = money(order.total_amount || order.totalAmount);
      if (!(totalAmount > 0)) totalAmount = Math.round(unitPrice * hours * 100) / 100;
      const serviceType = String(order.serviceType || order.service_type || order.serviceName || order.service || "陪玩").trim() || "陪玩";
      const companionName = String(order.companionName || order.companion_name || "").trim();
      const gameId = String(order.gameId || order.game_id || order.gameIdValue || order.game_id_value || "").trim();
      const couponCode = String(order.couponCode || order.coupon || "").trim();
      const paymentMethod = String(order.paymentMethod || order.payment_method || "catfood").trim().toLowerCase();
      const notes = String(order.notes || order.remark || order.description || "").trim();
      const game = String(order.game || serviceType || "陪玩").trim();
      if (action === "place_order") {
        if (!(unitPrice > 0)) return json(res, 400, { ok: false, message: "陪玩单价无效，请刷新后重试。" });
        if (!gameId) return json(res, 400, { ok: false, message: "请填写游戏 ID。" });
        if (!(totalAmount > 0)) return json(res, 400, { ok: false, message: "订单金额无效。" });
      } else if (!order.game || !order.description && !order.requirements && !order.title) {
        return json(res, 400, { ok: false, message: "请填写游戏和需求说明。" });
      }

      if (companionId) {
        let companions = await supabaseJson(restUrl("profiles", `?id=eq.${encodeURIComponent(companionId)}&limit=1`), { headers: serviceHeaders() });
        let companion = Array.isArray(companions) ? companions[0] : null;
        if (!companion || companion.role !== "companion") {
          // Accept companion_profiles.id as well as profiles.id (user_id).
          try {
            const cpRows = await supabaseJson(
              restUrl("companion_profiles", `?id=eq.${encodeURIComponent(companionId)}&select=id,user_id&limit=1`),
              { headers: serviceHeaders() }
            );
            const userId = Array.isArray(cpRows) && cpRows[0] ? cpRows[0].user_id : "";
            if (userId) {
              companions = await supabaseJson(restUrl("profiles", `?id=eq.${encodeURIComponent(userId)}&limit=1`), { headers: serviceHeaders() });
              companion = Array.isArray(companions) ? companions[0] : null;
              if (companion && companion.role === "companion") companionId = companion.id;
            }
          } catch (_) {
            /* keep original 404 path */
          }
        }
        if (!companion || companion.role !== "companion") {
          return json(res, 404, { ok: false, message: "指定陪玩不存在或不可下单。" });
        }
      }

      const useWallet = action === "place_order" && /cat.?food|wallet|猫粮|余额/.test(paymentMethod);
      // 指定陪玩下单：线下支付→待确认付款；猫粮支付成功→claimed（陪玩接单）。无陪玩→pending 进抢单大厅。
      let status = "awaiting_payment";
      if (action === "place_order") {
        if (useWallet) status = companionId ? "claimed" : "pending";
        else status = "awaiting_payment";
      }
      const title = companionName
        ? `${serviceType} · ${companionName} · ${hours}小时`
        : String(order.title || `${serviceType} · ${hours}小时`);
      const descriptionParts =
        action === "place_order"
          ? [
              notes || `${serviceType}订单`,
              gameId ? `游戏ID：${gameId}` : "",
              couponCode ? `优惠券：${couponCode}` : "",
              `付款方式：${paymentMethodLabel(paymentMethod)}`,
              companionName ? `指定陪玩：${companionName}` : "",
            ].filter(Boolean)
          : [String(order.description || order.requirements || order.service_content || notes || "")].filter(Boolean);

      const row = {
        order_no: orderNo(),
        boss_id: profile.id,
        companion_id: companionId || null,
        customer_service_id: null,
        order_type: companionId ? "direct_companion" : String(order.order_type || order.orderType || "custom"),
        game: action === "place_order" ? game : String(order.game || game || ""),
        title: action === "place_order" ? title : String(order.title || "自定义订单"),
        description: descriptionParts.join("\n"),
        hours,
        unit_price: unitPrice,
        total_amount: totalAmount,
        status,
        created_at: nowIso()
      };
      const rows = await supabaseJson(restUrl(TABLE), { method: "POST", headers: serviceHeaders(), body: JSON.stringify(row) });
      let saved = rows?.[0] || row;

      if (useWallet && action === "place_order") {
        try {
          const walletApi = await import("./_wallet.js");
          await walletApi.debitWallet({
            bossId: profile.id,
            amount: totalAmount,
            transactionType: "order_payment",
            idempotencyKey: `place-order:${saved.order_no || saved.id}`,
            reason: `下单支付 ${saved.order_no || saved.id}`,
            relatedOrderId: saved.id,
            operatorId: profile.id,
          });
          status = companionId ? "claimed" : "pending";
          if (saved.id) {
            const patched = await supabaseJson(restUrl(TABLE, `?id=eq.${encodeURIComponent(saved.id)}`), {
              method: "PATCH",
              headers: serviceHeaders(),
              body: JSON.stringify({ status }),
            });
            saved = patched?.[0] || { ...saved, status };
          }
        } catch (e) {
          if (saved.id) {
            await supabaseJson(restUrl(TABLE, `?id=eq.${encodeURIComponent(saved.id)}`), {
              method: "PATCH",
              headers: serviceHeaders(),
              body: JSON.stringify({ status: "cancelled", cancelled_at: nowIso() }),
            }).catch(() => null);
          }
          // 钱包 RPC 未部署：不可假装扣款成功；明示猫粮支付暂不可用。
          if (isMissingWalletRpc(e)) {
            return json(res, 503, {
              ok: false,
              code: "WALLET_UNAVAILABLE",
              message: "猫粮支付暂不可用",
            });
          }
          if (isWalletBalanceError(e)) {
            return json(res, 400, {
              ok: false,
              code: "INSUFFICIENT_BALANCE",
              message: e.message || "猫粮余额不足",
              rechargeUrl: "/recharge.html",
            });
          }
          throw e;
        }
      }

      const notify =
        status === "pending"
          ? `新订单已提交（待客服处理）。指定陪玩：${companionName || companionId || "未指定"}；服务：${serviceType}；时长：${hours}小时；金额：${totalAmount} 猫粮。`
          : `新订单已提交（待确认付款：${paymentMethodLabel(paymentMethod)}）。指定陪玩：${companionName || companionId || "未指定"}；请客服确认到账。`;
      await addSystemMessage(saved, profile.id, notify);
      return json(res, 200, {
        ok: true,
        message: status === "pending" ? "下单成功，已进入待客服处理。" : "订单已提交，请客服确认付款后进入处理。",
        order: viewOrder(saved),
      });
    }
    const id = String(body.id || body.order_id || body.orderId || "");
    if (!id) return json(res, 400, { ok: false, message: "缺少订单 ID。" });
    if (action === "confirm_companion") {
      const order = await patchOwnedOrder(profile, id, ["waiting_boss_confirm"], { status: "confirmed" }, "老板已确认陪玩，客服会继续跟进订单。");
      return json(res, 200, { ok: true, message: "已确认陪玩。", order });
    }
    if (action === "reject_companion") {
      const order = await patchOwnedOrder(profile, id, ["waiting_boss_confirm"], { status: "pending", companion_id: null, accepted_at: null }, "老板已选择换一个陪玩，请客服重新安排。");
      return json(res, 200, { ok: true, message: "已选择换一个陪玩，客服将重新安排。", order });
    }
    if (action === "cancel_order") {
      const order = await patchOwnedOrder(profile, id, ["awaiting_payment", "pending", "claimed", "waiting_boss_confirm", "confirmed"], { status: "cancelled", cancelled_at: nowIso() }, "老板已取消订单。");
      return json(res, 200, { ok: true, message: "订单已取消。", order });
    }
    if (action === "request_refund") {
      const order = await patchOwnedOrder(profile, id, ["confirmed", "in_progress", "completed"], { status: "refund_requested" }, "老板已申请退款，等待客服处理。");
      return json(res, 200, { ok: true, message: "退款申请已提交。", order });
    }
    return json(res, 400, { ok: false, message: "未知订单操作。" });
  } catch (error) {
    return json(res, error.status || 500, { ok: false, message: error.message || "订单接口异常" });
  }
}







