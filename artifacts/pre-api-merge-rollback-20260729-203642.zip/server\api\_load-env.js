import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

let loaded = false;

/** Load project-root .env.local into process.env (only fill missing keys). */
export function loadLocalEnv(fromUrl) {
  if (loaded) return;
  loaded = true;
  const here = path.dirname(fileURLToPath(fromUrl || import.meta.url));
  const candidates = [
    path.resolve(here, "../../.env.local"), // server/api → root
    path.resolve(here, "../.env.local"), // legacy api/ → root
    path.resolve(process.cwd(), ".env.local"),
  ];
  const envPath = candidates.find((p) => fs.existsSync(p));
  if (!envPath) return;
  const text = fs.readFileSync(envPath, "utf8");
  for (const rawLine of text.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith("#")) continue;
    const eq = line.indexOf("=");
    if (eq === -1) continue;
    const key = line.slice(0, eq).trim();
    const value = line.slice(eq + 1).trim().replace(/^['"]|['"]$/g, "");
    if (key && value && !process.env[key]) process.env[key] = value;
  }
}

loadLocalEnv(import.meta.url);
