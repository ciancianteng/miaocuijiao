const REQUIRED_ENV = ["SUPABASE_URL", "SUPABASE_ANON_KEY", "SUPABASE_SERVICE_ROLE_KEY"];
const ORDER_STATUS_TEXT = {
  awaiting_payment: "待付款确认",
  pending: "待接单",
  claimed: "陪玩已申请",
  waiting_boss_confirm: "待老板确认",
  confirmed: "已确认",
  in_progress: "进行中",
  completed: "已完成",
  cancelled: "已取消",
  refund_requested: "退款申请",
  refunded: "已退款"
};
const SERVICE_ROLES = new Set(["customer_service"]);

function json(res, status, data) { return res.status(status).json(data); }
function hasDb() { return REQUIRED_ENV.every((key) => process.env[key]); }
function restUrl(table, query = "") { return `${process.env.SUPABASE_URL}/rest/v1/${table}${query}`; }
function authUrl(path) { return `${process.env.SUPABASE_URL}/auth/v1/${path}`; }
function serviceHeaders(extra = {}) { return { apikey: process.env.SUPABASE_SERVICE_ROLE_KEY, Authorization: `Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY}`, "Content-Type": "application/json", Prefer: "return=representation", ...extra }; }
function anonHeaders(extra = {}) { return { apikey: process.env.SUPABASE_ANON_KEY, "Content-Type": "application/json", ...extra }; }
async function supabaseJson(url, init = {}) {
  const response = await fetch(url, init);
  const text = await response.text();
  let body = null;
  try { body = text ? JSON.parse(text) : null; } catch { body = text; }
  if (!response.ok) {
    const raw = typeof body === "string" ? body : "";
    const detail = body?.error_description || body?.message || body?.hint || body?.details || body?.error || raw || "";
    const code = body?.code ? ` [${body.code}]` : "";
    throw new Error((detail ? `${detail}${code}` : `Supabase 请求失败 (HTTP ${response.status})`) || `Supabase 请求失败 (HTTP ${response.status})`);
  }
  return body;
}
async function parseBody(req) { if (req.body && typeof req.body === "object") return req.body; const chunks = []; for await (const chunk of req) chunks.push(chunk); try { return JSON.parse(Buffer.concat(chunks).toString("utf8") || "{}"); } catch { return {}; } }
function tokenFrom(req) { return String(req.headers["x-mcj-service-token"] || req.headers.authorization || "").replace(/^Bearer\s+/i, "").trim(); }
function money(value) { const n = Number(String(value ?? "").replace(/[^\d.-]/g, "")); return Number.isFinite(n) ? n : 0; }
function nowIso() { return new Date().toISOString(); }
function orderNo(prefix = "MCJ") { return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`; }
async function tableRows(table, query = "") { const rows = await supabaseJson(restUrl(table, query), { headers: serviceHeaders() }); return Array.isArray(rows) ? rows : []; }
async function maybeRows(table, query = "") { try { return await tableRows(table, query); } catch { return []; } }
async function profileById(id) { if (!id) return null; const rows = await tableRows("profiles", `?id=eq.${encodeURIComponent(id)}&limit=1`); return rows[0] || null; }
async function profileByBossUid(uid) {
  const value = String(uid || "").trim();
  if (!value) return null;
  const rows = await maybeRows("profiles", `?boss_uid=eq.${encodeURIComponent(value)}&role=eq.boss&limit=1`);
  return rows[0] || null;
}
async function resolveBoss(input) {
  const value = String(input || "").trim();
  if (!value) return null;
  if (/^B\d+$/i.test(value)) return profileByBossUid(value.toUpperCase());
  const byId = await profileById(value);
  if (byId) return byId;
  return profileByBossUid(value);
}
async function profileMap(ids) { const uniq = [...new Set((ids || []).filter(Boolean))]; if (!uniq.length) return {}; const rows = await maybeRows("profiles", `?id=in.(${uniq.map(encodeURIComponent).join(",")})&limit=1000`); return rows.reduce((map, row) => { map[row.id] = row; return map; }, {}); }
async function authUserFromToken(token) { return supabaseJson(authUrl("user"), { headers: anonHeaders({ Authorization: `Bearer ${token}` }) }); }
async function requireService(req) { const token = tokenFrom(req); if (!token) throw Object.assign(new Error("请先登录客服端。"), { status: 401 }); const authUser = await authUserFromToken(token); const profile = await profileById(authUser.id); if (!profile || !SERVICE_ROLES.has(profile.role)) throw Object.assign(new Error("无权访问客服端。"), { status: 403 }); if (profile.status !== "active") throw Object.assign(new Error("该客服账号已被停用，请联系管理员。"), { status: 403 }); return { token, authUser, profile }; }
function safeProfile(row) {
  const bossUid = row.boss_uid || "";
  return {
    id: row.id,
    bossUid,
    boss_uid: bossUid,
    uid: bossUid || row.id,
    name: row.display_name || row.email || "-",
    email: row.email || "",
    phone: row.phone || "",
    avatar: row.avatar_url || "",
    status: row.status || "",
  };
}
function safeOrder(row, profiles = {}) {
  const boss = profiles[row.boss_id] || {};
  const companion = profiles[row.companion_id] || {};
  const service = profiles[row.customer_service_id] || {};
  const bossUid = boss.boss_uid || "";
  return {
    id: row.id,
    orderNo: row.order_no || row.id,
    bossId: row.boss_id || "",
    bossUid,
    bossName: boss.display_name || boss.email || bossUid || row.boss_id || "-",
    companionId: row.companion_id || "",
    companionName: companion.display_name || companion.email || "-",
    serviceId: row.customer_service_id || "",
    serviceName: service.display_name || service.email || "-",
    orderType: row.order_type || "custom",
    game: row.game || "",
    title: row.title || "",
    description: row.description || "",
    hours: money(row.hours),
    unitPrice: money(row.unit_price),
    totalAmount: money(row.total_amount),
    status: row.status || "",
    statusText: ORDER_STATUS_TEXT[row.status] || row.status || "-",
    createdAt: row.created_at || "",
    acceptedAt: row.accepted_at || "",
    startedAt: row.started_at || "",
    completedAt: row.completed_at || "",
    cancelledAt: row.cancelled_at || "",
  };
}
function safeMessage(row, profiles = {}) {
  const sender = profiles[row.sender_id] || {};
  let senderName = "";
  if (row.sender_role === "customer_service") {
    senderName = String(sender.display_name || "").trim() || "客服";
  } else if (row.sender_role === "boss") {
    senderName = String(sender.display_name || sender.boss_uid || "").trim() || "老板";
  }
  return {
    id: row.id,
    conversationId: row.conversation_id,
    senderId: row.sender_id,
    senderRole: row.sender_role,
    senderName,
    messageType: row.message_type || row.type || "text",
    content: row.content || "",
    orderId: row.order_id || "",
    createdAt: row.created_at || "",
    readAt: row.read_at || "",
  };
}
async function ensureConversation({ boss_id, companion_id = null, customer_service_id = null, order_id = null }) { let query = order_id ? `?order_id=eq.${encodeURIComponent(order_id)}&limit=1` : `?boss_id=eq.${encodeURIComponent(boss_id)}&order_id=is.null&order=updated_at.desc&limit=1`; const rows = await maybeRows("conversations", query); if (rows[0]) return rows[0]; const inserted = await supabaseJson(restUrl("conversations"), { method: "POST", headers: serviceHeaders(), body: JSON.stringify({ boss_id, companion_id, customer_service_id, order_id, status: customer_service_id ? "open" : "waiting_service", created_at: nowIso(), updated_at: nowIso() }) }); return inserted[0] || null; }
async function addMessage(conversation, sender, senderRole, content, messageType = "system", orderId = null) { if (!conversation) return null; const rows = await supabaseJson(restUrl("messages"), { method: "POST", headers: serviceHeaders(), body: JSON.stringify({ conversation_id: conversation.id, sender_id: sender, sender_role: senderRole, message_type: messageType, content: String(content || ""), order_id: orderId || conversation.order_id || null, created_at: nowIso() }) }); await supabaseJson(restUrl("conversations", `?id=eq.${encodeURIComponent(conversation.id)}`), { method: "PATCH", headers: serviceHeaders(), body: JSON.stringify({ updated_at: nowIso() }) }); return rows[0] || null; }
async function allocateBossUid() {
  const rows = await maybeRows("profiles", "?role=eq.boss&select=boss_uid&boss_uid=not.is.null&order=created_at.desc&limit=200");
  let next = 100001;
  for (const row of rows) {
    const match = String(row?.boss_uid || "").trim().match(/^B(\d+)$/i);
    if (match) next = Math.max(next, Number(match[1]) + 1);
  }
  for (let attempt = 0; attempt < 8; attempt += 1) {
    const candidate = `B${next + attempt}`;
    const existing = await maybeRows("profiles", `?boss_uid=eq.${encodeURIComponent(candidate)}&select=id&limit=1`);
    if (!existing.length) return candidate;
  }
  return `B${Date.now().toString().slice(-9)}`;
}
async function ensureBossUid(profile) {
  if (!profile?.id) return profile;
  if (profile.boss_uid && String(profile.boss_uid).trim()) return profile;
  for (let attempt = 0; attempt < 5; attempt += 1) {
    const bossUid = await allocateBossUid();
    try {
      const rows = await supabaseJson(restUrl("profiles", `?id=eq.${encodeURIComponent(profile.id)}`), {
        method: "PATCH",
        headers: serviceHeaders(),
        body: JSON.stringify({ boss_uid: bossUid }),
      });
      const saved = Array.isArray(rows) ? rows[0] : { ...profile, boss_uid: bossUid };
      if (saved?.boss_uid) return saved;
    } catch (_) {}
  }
  return profile;
}
async function loadBootstrap(serviceProfile) { const [ordersRaw, conversationsRaw, messagesRawDesc, profilesRaw, companionsRaw, reportsRaw, payrollsRaw] = await Promise.all([ maybeRows("orders", "?order=created_at.desc&limit=300"), maybeRows("conversations", "?order=updated_at.desc&limit=300"), maybeRows("messages", "?order=created_at.desc&limit=1500"), maybeRows("profiles", "?limit=1000"), maybeRows("companion_profiles", "?limit=1000"), maybeRows("customer_service_reports", `?customer_service_id=eq.${encodeURIComponent(serviceProfile.id)}&order=created_at.desc&limit=100`), maybeRows("staff_payrolls", `?staff_id=eq.${encodeURIComponent(serviceProfile.id)}&order=created_at.desc&limit=100`) ]); const messagesRaw = (messagesRawDesc || []).slice().reverse(); const profiles = profilesRaw.reduce((map, row) => { map[row.id] = row; return map; }, {});
  // Backfill missing boss_uid so CS pool always shows 老板 UID.
  const bossIdsNeedingUid = [...new Set((conversationsRaw || []).map((c) => c.boss_id).filter((id) => id && profiles[id] && !profiles[id].boss_uid))];
  for (const id of bossIdsNeedingUid.slice(0, 20)) {
    profiles[id] = await ensureBossUid(profiles[id]);
  }
  const orders = ordersRaw.map((row) => safeOrder(row, profiles)); const msgByConv = messagesRaw.reduce((map, msg) => { (map[msg.conversation_id] = map[msg.conversation_id] || []).push(msg); return map; }, {}); const conversations = conversationsRaw.map((row) => { const boss = profiles[row.boss_id] || {}; const service = profiles[row.customer_service_id] || {}; const msgs = msgByConv[row.id] || []; const last = msgs[msgs.length - 1] || {}; const bossUid = String(boss.boss_uid || "").trim(); return { id: row.id, bossId: row.boss_id || "", bossUid: bossUid || "", bossName: boss.display_name || bossUid || "老板", orderId: row.order_id || "", orderNo: (orders.find((o) => o.id === row.order_id) || {}).orderNo || "", currentServiceId: row.customer_service_id || "", currentServiceName: String(service.display_name || "").trim() || (row.customer_service_id ? "客服" : "待接待"), status: row.customer_service_id ? "接待中" : "待接待", lastMessage: last.content || "", lastTime: last.created_at || row.updated_at || "", unread: msgs.filter((m) => m.sender_role === "boss" && !m.read_at).length, updatedAt: row.updated_at || "" }; }); const bosses = profilesRaw.filter((p) => p.role === "boss" && p.status === "active").map(safeProfile); const companions = companionsRaw.map((cp) => { const p = profiles[cp.user_id] || {}; return { id: cp.user_id, name: cp.nickname || p.display_name || p.email || "陪玩", game: cp.game || "", level: cp.level_name || "", price: money(cp.price), status: p.status || "", verificationStatus: cp.verification_status || "", onlineStatus: cp.online_status || "" }; }).filter((p) => p.status === "active"); const today = new Date().toISOString().slice(0, 10); const receptionStats = await (await import("./_service-receptions.js")).loadReceptionStats(serviceProfile.id, conversations); const summary = { waitingConversations: conversations.filter((c) => !c.currentServiceId).length, currentReceptions: receptionStats.currentReceptions || 0, todayReceptions: receptionStats.todayReceptions || 0, monthReceptions: receptionStats.monthReceptions || 0, awaitingPayment: orders.filter((o) => o.status === "awaiting_payment").length, pendingOrders: orders.filter((o) => o.status === "pending").length, waitingBossConfirm: orders.filter((o) => o.status === "waiting_boss_confirm").length, inProgress: orders.filter((o) => o.status === "in_progress").length, refundRequested: orders.filter((o) => o.status === "refund_requested").length, todayHandled: orders.filter((o) => o.serviceId === serviceProfile.id && String(o.createdAt).slice(0, 10) === today).length }; const payrollStatusText = { draft: "草稿", pending_review: "待审核", approved_pending_pay: "已通过待付款", rejected: "已驳回", paying: "付款处理中", paid_pending_receipt: "已付款待上传收据", completed: "已发放", pay_failed: "付款失败", cancelled: "已撤销" }; const payrolls = (payrollsRaw || []).map((row) => { const snap = row.payment_account_snapshot || {}; return { id: row.id, payrollNo: row.payroll_no, periodStart: row.period_start, periodEnd: row.period_end, baseSalaryRm: money(row.base_salary_rm), bonusRm: money(row.bonus_rm), deductionRm: money(row.deduction_rm), netSalaryRm: money(row.net_salary_rm), accountLast4: snap.account_last4 || "", status: row.status, statusText: payrollStatusText[row.status] || row.status, paidAt: row.paid_at || "", note: row.note || "" }; }); return { staff: safeProfile(serviceProfile), summary, conversations, messages: messagesRaw.map((row) => safeMessage(row, profiles)), orders, bosses, companions, reports: reportsRaw, payrolls, orderStatuses: ORDER_STATUS_TEXT }; }
async function orderById(id) { const rows = await tableRows("orders", `?id=eq.${encodeURIComponent(id)}&limit=1`); return rows[0] || null; }
async function patchOrder(id, patch) { const rows = await supabaseJson(restUrl("orders", `?id=eq.${encodeURIComponent(id)}`), { method: "PATCH", headers: serviceHeaders(), body: JSON.stringify(patch) }); return rows[0] || null; }
async function handler(req, res) { if (!hasDb()) return json(res, req.method === "GET" ? 200 : 503, { ok: req.method === "GET", configured: false, message: "未配置 Supabase，客服端不返回假数据。", data: { staff: {}, summary: { waitingConversations: 0, currentReceptions: 0, todayReceptions: 0, monthReceptions: 0, awaitingPayment: 0, pendingOrders: 0, waitingBossConfirm: 0, inProgress: 0, refundRequested: 0, todayHandled: 0 }, conversations: [], messages: [], orders: [], bosses: [], companions: [], reports: [], orderStatuses: ORDER_STATUS_TEXT } }); try { const action = String(req.method === "GET" ? req.query.action || "bootstrap" : req.body?.action || ""); if (action === "login") { const body = await parseBody(req); const email = String(body.account || body.email || "").trim().toLowerCase(); const password = String(body.password || ""); if (!email || !password) return json(res, 400, { ok: false, message: "请输入邮箱和密码。" }); let auth; try { auth = await supabaseJson(authUrl("token?grant_type=password"), { method: "POST", headers: anonHeaders(), body: JSON.stringify({ email, password }) }); } catch { return json(res, 401, { ok: false, message: "账号或密码错误。" }); } const profile = await profileById(auth.user?.id); if (!profile || profile.role !== "customer_service") return json(res, 403, { ok: false, message: "无权访问客服端。" }); if (profile.status !== "active") return json(res, 403, { ok: false, message: "该客服账号已被停用，请联系管理员。" }); return json(res, 200, { ok: true, session: { token: auth.access_token, user: safeProfile(profile), remember: !!body.remember } }); }
    const service = await requireService(req); if (req.method === "GET") return json(res, 200, { ok: true, configured: true, data: await loadBootstrap(service.profile) }); const body = await parseBody(req);
    if (action === "take_conversation") {
      const id = String(body.id || "");
      const existing = (await tableRows("conversations", `?id=eq.${encodeURIComponent(id)}&limit=1`))[0];
      if (!existing) return json(res, 404, { ok: false, message: "会话不存在。" });
      if (existing.customer_service_id && existing.customer_service_id !== service.profile.id) {
        const other = await profileById(existing.customer_service_id);
        const otherName = String(other?.display_name || "").trim() || "其他客服";
        return json(res, 409, { ok: false, message: `该会话已由客服 ${otherName} 接待。` });
      }
      if (existing.customer_service_id === service.profile.id) {
        return json(res, 200, { ok: true, message: "你已在接待该会话。", conversation: existing });
      }
      const nick = String(service.profile.display_name || "").trim() || "客服";
      // 原子认领：仅当仍无人接待时成功，避免并发覆盖。
      const rows = await supabaseJson(restUrl("conversations", `?id=eq.${encodeURIComponent(id)}&customer_service_id=is.null`), {
        method: "PATCH",
        headers: serviceHeaders(),
        body: JSON.stringify({ customer_service_id: service.profile.id, status: "open", updated_at: nowIso() }),
      });
      const conversation = Array.isArray(rows) ? rows[0] : null;
      if (!conversation) {
        const again = (await tableRows("conversations", `?id=eq.${encodeURIComponent(id)}&limit=1`))[0];
        if (again?.customer_service_id === service.profile.id) {
          return json(res, 200, { ok: true, message: "你已在接待该会话。", conversation: again });
        }
        const other = again?.customer_service_id ? await profileById(again.customer_service_id) : null;
        const otherName = String(other?.display_name || "").trim() || "其他客服";
        return json(res, 409, { ok: false, message: `该会话已由客服 ${otherName} 接待。` });
      }
      try {
        await (await import("./_service-receptions.js")).startReceptionRecord(conversation, service.profile.id);
      } catch (_) {}
      // sender_role 必须是 enum 合法值；系统提示用 message_type=system。
      await addMessage(conversation, service.profile.id, "customer_service", `当前由客服 ${nick} 为您服务`, "system");
      return json(res, 200, { ok: true, message: "已接待该会话。", conversation });
    }
    if (action === "end_conversation") {
      const id = String(body.id || body.conversation_id || "");
      const existing = (await tableRows("conversations", `?id=eq.${encodeURIComponent(id)}&limit=1`))[0];
      if (!existing) return json(res, 404, { ok: false, message: "会话不存在。" });
      if (!existing.customer_service_id) {
        return json(res, 400, { ok: false, message: "该会话当前无人接待。" });
      }
      if (existing.customer_service_id !== service.profile.id) {
        const other = await profileById(existing.customer_service_id);
        const otherName = String(other?.display_name || "").trim() || "其他客服";
        return json(res, 403, { ok: false, message: `只有接待中的客服可结束。当前由 ${otherName} 接待。` });
      }
      const rows = await supabaseJson(restUrl("conversations", `?id=eq.${encodeURIComponent(id)}&customer_service_id=eq.${encodeURIComponent(service.profile.id)}`), {
        method: "PATCH",
        headers: serviceHeaders(),
        body: JSON.stringify({ customer_service_id: null, status: "waiting_service", updated_at: nowIso() }),
      });
      const conversation = Array.isArray(rows) ? rows[0] : existing;
      try {
        await (await import("./_service-receptions.js")).endReceptionRecord(id, service.profile.id);
      } catch (_) {}
      // 会话与历史消息保留；仅解除接待锁并通知老板。
      await addMessage(conversation || existing, service.profile.id, "customer_service", "客服已结束本次服务。", "system");
      return json(res, 200, { ok: true, message: "已结束接待。", conversation });
    }
    if (action === "send_message") {
      const conversation = (await tableRows("conversations", `?id=eq.${encodeURIComponent(String(body.conversation_id || body.id || ""))}&limit=1`))[0];
      if (!conversation) return json(res, 404, { ok: false, message: "会话不存在。" });
      if (!conversation.customer_service_id) {
        return json(res, 403, { ok: false, message: "请先点击接待后再回复。" });
      }
      if (conversation.customer_service_id !== service.profile.id) {
        return json(res, 403, { ok: false, message: "该会话已由其他客服接待。" });
      }
      const msg = await addMessage(conversation, service.profile.id, "customer_service", String(body.content || ""), "text");
      const messageRow = msg
        ? Object.assign({}, safeMessage(msg, { [service.profile.id]: service.profile }), {
            senderName: String(service.profile.display_name || "").trim() || "客服",
          })
        : null;
      return json(res, 200, { ok: true, message: "消息已发送。", messageRow });
    }
    if (action === "create_order") { const o = body.order || body; const bossInput = String(o.boss_id || o.bossId || o.boss || o.bossUid || o.boss_uid || ""); const boss = await resolveBoss(bossInput); if (!boss || boss.role !== "boss") return json(res, 400, { ok: false, message: "请选择真实老板账号（支持老板 UID / 内部 ID）。" }); const bossId = boss.id; const hours = money(o.hours || o.duration || 1) || 1; const unit = money(o.unit_price || o.unitPrice || o.price); const total = money(o.total_amount || o.totalAmount || o.amount) || unit * hours; if (!o.game || !o.description && !o.title || total <= 0) return json(res, 400, { ok: false, message: "请完整填写游戏、需求和金额。" }); const payload = { order_no: orderNo("CS"), boss_id: bossId, companion_id: o.companion_id || o.companionId || null, customer_service_id: service.profile.id, order_type: String(o.order_type || o.orderType || "customer_service"), game: String(o.game || ""), title: String(o.title || o.description || "客服创建订单"), description: String(o.description || o.requirements || o.title || ""), hours, unit_price: unit || total / hours, total_amount: total, status: "awaiting_payment", created_at: nowIso() }; const rows = await supabaseJson(restUrl("orders"), { method: "POST", headers: serviceHeaders(), body: JSON.stringify(payload) }); const order = rows[0]; const conversation = await ensureConversation({ boss_id: bossId, companion_id: order.companion_id, customer_service_id: service.profile.id, order_id: order.id }); await addMessage(conversation, service.profile.id, "customer_service", `订单卡片：${order.order_no} / ${order.game} / ${money(order.total_amount).toFixed(2)} 猫粮。请确认付款。`, "order_card", order.id); return json(res, 200, { ok: true, message: "订单已创建，等待付款确认。", order }); }
    if (action === "confirm_payment") { const order = await orderById(String(body.id || body.order_id || "")); if (!order) return json(res, 404, { ok: false, message: "订单不存在。" }); if (order.status !== "awaiting_payment") return json(res, 400, { ok: false, message: "只有待付款确认订单可以确认付款。" }); /* 指定陪玩：claimed→陪玩接单；无陪玩：pending→抢单大厅 */ const next = order.companion_id ? "claimed" : "pending"; const patched = await patchOrder(order.id, { status: next, customer_service_id: service.profile.id }); const conversation = await ensureConversation({ boss_id: order.boss_id, companion_id: order.companion_id, customer_service_id: service.profile.id, order_id: order.id }); const sysMsg = order.companion_id ? "客服已确认付款，等待指定陪玩接单。" : "客服已确认付款，订单已进入抢单大厅。"; await addMessage(conversation, service.profile.id, "customer_service", sysMsg, "system", order.id); return json(res, 200, { ok: true, message: "已确认付款。", order: patched }); }
    if (action === "assign_companion") { const order = await orderById(String(body.id || body.order_id || "")); const companionId = String(body.companion_id || body.companionId || ""); const companion = await profileById(companionId); if (!order || !companion || companion.role !== "companion") return json(res, 400, { ok: false, message: "订单或陪玩不存在。" }); const patched = await patchOrder(order.id, { companion_id: companionId, customer_service_id: service.profile.id, status: "waiting_boss_confirm", accepted_at: nowIso() }); const conversation = await ensureConversation({ boss_id: order.boss_id, companion_id: companionId, customer_service_id: service.profile.id, order_id: order.id }); await addMessage(conversation, service.profile.id, "customer_service", `已推荐陪玩：${companion.display_name || companion.email}，请老板确认。`, "order_card", order.id); return json(res, 200, { ok: true, message: "已指定陪玩，等待老板确认。", order: patched }); }
    if (action === "update_order_status") { const id = String(body.id || body.order_id || ""); const status = String(body.status || ""); if (!ORDER_STATUS_TEXT[status]) return json(res, 400, { ok: false, message: "订单状态无效。" }); const patch = { status, customer_service_id: service.profile.id }; if (status === "completed") patch.completed_at = nowIso(); if (status === "cancelled") patch.cancelled_at = nowIso(); const patched = await patchOrder(id, patch); const conversation = patched ? await ensureConversation({ boss_id: patched.boss_id, companion_id: patched.companion_id, customer_service_id: service.profile.id, order_id: patched.id }) : null; await addMessage(conversation, service.profile.id, "customer_service", `订单状态已更新为：${ORDER_STATUS_TEXT[status]}`, "system", id); return json(res, 200, { ok: true, message: "订单状态已更新。", order: patched }); }
    if (action === "refund_decision") { const order = await orderById(String(body.id || body.order_id || "")); if (!order || order.status !== "refund_requested") return json(res, 400, { ok: false, message: "只有退款申请中的订单可以处理退款。" }); const decision = String(body.decision || ""); const note = String(body.note || ""); if (!note) return json(res, 400, { ok: false, message: "退款处理必须填写备注。" }); if (decision === "approve") { const patched = await patchOrder(order.id, { status: "refunded", customer_service_id: service.profile.id }); try { const walletApi = await import("./_wallet.js"); const amount = money(order.total_amount); if (amount > 0) { await walletApi.creditWallet({ bossId: order.boss_id, transactionType: "refund", amount, balanceType: "paid", idempotencyKey: `refund-paid:${order.id}`, reason: note || "订单退款", relatedOrderId: order.id, operatorId: service.profile.id }); } } catch (e) { /* wallet sql may be missing; keep legacy tx */ await supabaseJson(restUrl("transactions"), { method: "POST", headers: serviceHeaders(), body: JSON.stringify({ user_id: order.boss_id, order_id: order.id, transaction_type: "refund", amount: money(order.total_amount), status: "completed", note, created_at: nowIso() }) }).catch(() => null); } try { const pop = await import("./_popularity.js"); pop.scheduleRecomputeSoft(); } catch (e) { /* optional */ } return json(res, 200, { ok: true, message: "退款已批准。", order: patched }); } const restore = ["in_progress", "completed", "cancelled"].includes(String(body.restore_status)) ? String(body.restore_status) : "in_progress"; const patched = await patchOrder(order.id, { status: restore, customer_service_id: service.profile.id }); return json(res, 200, { ok: true, message: "退款已拒绝。", order: patched }); }
    if (action === "submit_report") { return json(res, 400, { ok: false, message: "客服不能自行填写应付工资。请查看工资记录，如有异议请提交申诉。" }); }
    if (action === "appeal_payroll") {
      const payrollId = String(body.payrollId || body.payroll_id || body.id || "").trim();
      const reason = String(body.reason || "").trim();
      if (!payrollId || !reason) return json(res, 400, { ok: false, message: "请选择工资单并填写申诉原因。" });
      const rows = await maybeRows("staff_payrolls", `?id=eq.${encodeURIComponent(payrollId)}&staff_id=eq.${encodeURIComponent(service.profile.id)}&limit=1`);
      if (!rows[0]) return json(res, 404, { ok: false, message: "工资单不存在。" });
      const inserted = await supabaseJson(restUrl("staff_payroll_appeals"), {
        method: "POST",
        headers: serviceHeaders(),
        body: JSON.stringify({ payroll_id: payrollId, staff_id: service.profile.id, reason, status: "pending", created_at: nowIso() }),
      });
      return json(res, 200, { ok: true, message: "工资申诉已提交，等待管理员处理。", appeal: inserted[0] || null });
    }
    if (action === "apply_compensation") {
      try {
        const settings = await (await import("./_wallet.js")).getWalletSettings();
        if (settings.allow_cs_apply === false) return json(res, 403, { ok: false, message: "系统已关闭客服补偿申请。" });
        const bossInput = String(body.boss_id || body.bossId || body.bossUid || body.boss_uid || "").trim();
        const boss = await resolveBoss(bossInput);
        if (!boss || boss.role !== "boss") return json(res, 400, { ok: false, message: "请填写真实老板 UID / ID。" });
        const amount = money(body.suggested_amount || body.suggestedAmount || body.amount);
        const maxReq = money(settings.cs_max_per_request != null ? settings.cs_max_per_request : 100);
        if (amount <= 0) return json(res, 400, { ok: false, message: "建议补偿数量必须大于 0。" });
        if (amount > maxReq) return json(res, 400, { ok: false, message: `单笔申请不能超过 ${maxReq} 猫粮。` });
        const reason = String(body.reason || "").trim();
        if (!reason) return json(res, 400, { ok: false, message: "请填写差评或投诉原因。" });
        const today = new Date().toISOString().slice(0, 10);
        const todayRows = await maybeRows(
          "compensation_requests",
          `?applicant_id=eq.${encodeURIComponent(service.profile.id)}&created_at=gte.${encodeURIComponent(today + "T00:00:00.000Z")}&select=suggested_amount`
        );
        const todaySum = todayRows.reduce((n, r) => n + money(r.suggested_amount), 0);
        const maxDay = money(settings.cs_max_per_day != null ? settings.cs_max_per_day : 300);
        if (todaySum + amount > maxDay) return json(res, 400, { ok: false, message: `今日申请额度不足（上限 ${maxDay}）。` });
        const rows = await supabaseJson(restUrl("compensation_requests"), {
          method: "POST",
          headers: serviceHeaders(),
          body: JSON.stringify({
            boss_id: boss.id,
            related_order_id: body.related_order_id || body.relatedOrderId || body.order_id || null,
            request_type: String(body.request_type || body.requestType || "bad_review"),
            suggested_amount: amount,
            balance_type: "bonus",
            reason,
            staff_note: String(body.staff_note || body.staffNote || body.note || ""),
            evidence_urls: String(body.evidence_urls || body.evidenceUrls || ""),
            status: "pending",
            applicant_id: service.profile.id,
            notify_boss: body.notify_boss !== false,
            created_at: nowIso(),
          }),
        });
        return json(res, 200, { ok: true, message: "补偿申请已提交，等待管理员审核。", request: rows[0] || null });
      } catch (error) {
        const real = String(error?.message || error || "").trim();
        const text = `${real} ${JSON.stringify(error?.body || "")}`;
        if (error?.status === 404 || /Could not find the table|schema cache|PGRST205|does not exist/i.test(text)) {
          // Do NOT swallow the real Supabase error. Compensation failure must not break CS bootstrap/dashboard.
          return json(res, 503, {
            ok: false,
            message:
              "补偿申请表 public.compensation_requests 不存在。请到 Supabase SQL Editor 执行 supabase/service-compensation.sql 后再提交。" +
              (real ? `（Supabase：${real}）` : ""),
            supabaseMessage: real || null,
            table: "compensation_requests",
            sqlFile: "supabase/service-compensation.sql",
          });
        }
        throw error;
      }
    }
    return json(res, 400, { ok: false, message: "未知客服端操作。" }); } catch (error) { return json(res, error.status || 500, { ok: false, message: error.message || "客服端接口异常。" }); } }
export default handler;
