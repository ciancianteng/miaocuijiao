﻿const REQUIRED_ENV = ["SUPABASE_URL", "SUPABASE_SERVICE_ROLE_KEY"];

function json(res, status, data) {
  res.status(status).json(data);
}
function hasDb() {
  return REQUIRED_ENV.every((key) => process.env[key]);
}
function headers() {
  return {
    apikey: process.env.SUPABASE_SERVICE_ROLE_KEY,
    Authorization: `Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY}`,
    "Content-Type": "application/json",
  };
}
function restUrl(table, query = "") {
  return `${process.env.SUPABASE_URL}/rest/v1/${table}${query}`;
}
async function supabaseJson(url, init = {}) {
  const response = await fetch(url, init);
  const text = await response.text();
  let body = null;
  try {
    body = text ? JSON.parse(text) : null;
  } catch {
    body = text;
  }
  if (!response.ok) throw new Error(body?.message || body?.hint || body?.details || "陪玩数据库请求失败");
  return body;
}
function money(value) {
  const n = Number(String(value ?? "").replace(/[^\d.-]/g, ""));
  return Number.isFinite(n) ? n : 0;
}
function availabilityCode(row = {}) {
  const raw = String(row.availability_status || row.online_status || "offline").toLowerCase();
  if (raw === "online") return "online";
  if (raw === "busy") return "busy";
  if (raw === "paused") return "paused";
  return "offline";
}
function availabilityText(code) {
  return ({ online: "在线可接单", busy: "忙碌中", paused: "暂停接单", offline: "离线" })[code] || "离线";
}
function publicCompanion(row = {}, profile = {}) {
  const avail = availabilityCode(row);
  const publicId = row.companion_uid ? `P${row.companion_uid}` : "";
  return {
    id: row.user_id || row.id,
    uid: row.user_id || row.id,
    publicId,
    companionUid: row.companion_uid || null,
    companionProfileId: row.id,
    name: row.nickname || profile.display_name || "未命名陪玩",
    nickname: row.nickname || profile.display_name || "未命名陪玩",
    game: row.game || "",
    mainGame: row.game || "",
    level: row.level_name || "未设置等级",
    levelName: row.level_name || "未设置等级",
    levelId: row.level_id || "",
    price: money(row.price),
    priceValue: money(row.price),
    hourlyPrice: money(row.price),
    pricingUnit: row.pricing_unit || "小时",
    availabilityStatus: avail,
    availabilityText: availabilityText(avail),
    onlineStatus: availabilityText(avail),
    status: availabilityText(avail),
    canOrderNow: avail === "online",
    avatar: profile.avatar_url || row.card_image_url || "assets/meow-cuijiao-brand.jpg",
    cover: row.card_image_url || profile.avatar_url || "assets/meow-cuijiao-brand.jpg",
    voiceUrl: row.voice_url || "",
    cardImageUrl: row.card_image_url || "",
    desc: row.description || "",
    description: row.description || "",
    tags: String(row.tags || "")
      .split(/[,，、]/)
      .map((t) => t.trim())
      .filter(Boolean),
    commissionRate: money(row.commission_rate),
    giftCommissionRate: money(row.gift_commission_rate),
    verificationStatus: row.verification_status || "",
    depositStatus: row.deposit_status || "",
    lastOnlineAt: row.last_online_at || "",
    statusUpdatedAt: row.status_updated_at || "",
  };
}
async function loadCompanions(id = "") {
  let query = id
    ? `?or=(user_id.eq.${encodeURIComponent(id)},companion_uid.eq.${encodeURIComponent(String(id).replace(/^P/i, ""))})&verification_status=eq.approved&limit=1`
    : "?verification_status=eq.approved&order=updated_at.desc&limit=300";
  // Fallback if companion_uid column missing
  let rows;
  try {
    rows = await supabaseJson(restUrl("companion_profiles", query), { headers: headers() });
  } catch (e) {
    if (id && /companion_uid|column/i.test(String(e.message || ""))) {
      rows = await supabaseJson(
        restUrl("companion_profiles", `?user_id=eq.${encodeURIComponent(id)}&verification_status=eq.approved&limit=1`),
        { headers: headers() }
      );
    } else throw e;
  }
  const companions = Array.isArray(rows) ? rows : [];
  const userIds = [...new Set(companions.map((row) => row.user_id).filter(Boolean))];
  if (!userIds.length) return [];
  const profiles = await supabaseJson(
    restUrl("profiles", `?id=in.(${userIds.map(encodeURIComponent).join(",")})&role=eq.companion&status=eq.active`),
    { headers: headers() }
  );
  const profileMap = Object.fromEntries((profiles || []).map((row) => [row.id, row]));
  return companions.filter((row) => profileMap[row.user_id]).map((row) => publicCompanion(row, profileMap[row.user_id]));
}

export default async function handler(req, res) {
  if (req.method !== "GET") {
    res.setHeader("Allow", "GET");
    return json(res, 405, { ok: false, message: "Method Not Allowed" });
  }
  if (!hasDb()) {
    return json(res, 200, { ok: true, configured: false, companions: [], message: "未配置 Supabase，陪玩大厅不返回假数据。" });
  }
  try {
    const companions = await loadCompanions(String(req.query.id || req.query.uid || req.query.player || ""));
    return json(res, 200, { ok: true, configured: true, companions });
  } catch (error) {
    return json(res, 500, { ok: false, message: error.message || "陪玩列表接口异常" });
  }
}
